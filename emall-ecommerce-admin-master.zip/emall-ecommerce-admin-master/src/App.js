import React from "react";
import { Switch, Route } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { general } from "./apis";
import { PrivateRoute, PublicRoute, NavBar, Header, ProductModal } from "./components";
import styled from "styled-components";
import {
  Me,
  Login,
  Product,
  ProductNew,
  ProductEdit,
  Tag,
  Brand,
  Sale,
  Home,
  Category,
  Option,
  Attribute,
  Order,
  OrderDetail,
  Color,
  Banner,
  Notfound,
  Highlight,
  NewOrder,
  Delivery,
  Staff
} from "./pages";

export default () => {
  const dispatch = useDispatch();
  const { token } = useSelector((state) => state.auth);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const asyncFn = async () => {
      try {
        await Promise.all([general.init()(dispatch)]);
        setLoading(false);
      } catch (e) {
        setLoading(false);
      }
    };

    if (token) {
      asyncFn();
    } else {
      setLoading(false);
    }
  }, [dispatch, token]);

  if (loading) return <div>loading...</div>;

  return (
    <div>
      <Switch>
        <PublicRoute path="/login" component={Login} />
        <PrivateRoute path="/">
          <Header />

          <Container>
            <div className="content">
              <div className="navbar">
                <NavBar />
              </div>
              <div className="wrapper">
                <Switch>
                  <Route path="/product" component={Product} exact />
                  <Route path="/product/new" component={ProductNew} />
                  <Route path="/product/:id" component={ProductEdit} />
                  <Route path="/tag" component={Tag} />
                  <Route path="/brand" component={Brand} />
                  <Route path="/sale" component={Sale} />
                  <Route path="/hightlight" component={Highlight} />
                  <Route path="/category" component={Category} />
                  <Route path="/order" component={Order} exact />
                  <Route path="/order/new" component={NewOrder} exact />
                  <Route path="/order/detail/:id" component={OrderDetail} exact />
                  <Route path="/delivery" component={Delivery} exact />
                  <Route path="/me" component={Me} />
                  <Route path="/settings/home" component={Home} />
                  <Route path="/settings/option" component={Option} />
                  <Route path="/settings/attribute" component={Attribute} />
                  <Route path="/settings/color" component={Color} />
                  <Route path="/settings/banner" component={Banner} />
                  <Route path="/settings/staff" component={Staff} />
                  <Route component={Notfound} />
                </Switch>
              </div>
            </div>
          </Container>
        </PrivateRoute>
      </Switch>

      <ProductModal />
    </div>
  );
};
const Container = styled.div`
  padding: 40px 50px;
  .content {
    position: relative;
    width: 100%;
    .navbar {
      display: flex;
      width: 230px;
      border-right: 1px solid #e8e8e8;
      min-height: 100%;
      flex-direction: column;
      position: absolute;
      left: 0;
      top: 0;
    }
    .wrapper {
      position: relative;
      padding-left: 230px;
    }
  }
`;