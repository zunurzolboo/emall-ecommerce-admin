import arrayToTree from "array-to-tree";

const initialState = {
  tags            : [],
  categories      : [],
  brands          : [],
  mappedCategories: {},
  mappedBrands    : {},
  orderStatus     : {},
  deliveryStatus  : {},
  paymentMethod   : {},
  bannerType      : {},
  staffRoles      : [],
  mappedStaffRoles: {}
};

const makeMappedCategories = (payload) => {
  let mapped = payload.reduce((accumilator, iterator) => ({
    ...accumilator,
    [iterator._id]: iterator
  }), {});

  return mapped;
};

const general = (state = initialState, action) => {
  switch (action.type) {
    case "general/init": {
      const { tags, categories, brands, cities, districts, quarters, orderStatus, deliveryStatus, paymentMethod, bannerType, staffRoles } = action.payload;

      return {
        ...state,
        categories: arrayToTree(categories, {
          parentProperty: "parent",
          customID      : "_id"
        }),
        mappedCategories: makeMappedCategories(categories),
        brands,
        mappedBrands    : brands.reduce((accumilator, iterator) => ({
          ...accumilator,
          [iterator._id]: iterator
        }), {}),
        tags,
        cities,
        districts,
        quarters,
        orderStatus,
        deliveryStatus,
        paymentMethod,
        staffRoles,
        mappedStaffRoles: staffRoles.reduce((accumilator, iterator) => ({
          ...accumilator,
          [iterator._id]: iterator
        }), {}),
        bannerType
      };
    }
    case "general/category": {
      return {
        ...state,
        categories: arrayToTree(action.payload, {
          parentProperty: "parent",
          customID      : "_id"
        }),
        mappedCategories: makeMappedCategories(action.payload)
      };
    }
    default:
      return state;
  }
};

export default general;
