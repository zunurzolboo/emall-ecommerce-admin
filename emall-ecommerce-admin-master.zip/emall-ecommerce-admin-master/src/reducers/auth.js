const initialState = {
  user  : {},
  token : null,
  tokens: []
};

const auth = (state = initialState, action) => {
  switch (action.type) {
    case "auth/change":
      const { accessToken, refreshToken } = action.payload;

      return {
        ...state,
        token : accessToken,
        tokens: [accessToken, refreshToken]
      };
    case "auth/me":
      return {
        ...state,
        user: action.payload,
      };
    case "auth/logout":
      return initialState;
    default:
      return state;
  }
};

export default auth;
