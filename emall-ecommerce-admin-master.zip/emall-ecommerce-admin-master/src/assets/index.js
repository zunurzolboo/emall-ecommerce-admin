import { ReactComponent as WarningIcon } from "./warning.svg";

export { WarningIcon };
