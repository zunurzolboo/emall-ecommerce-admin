import React from "react";
import styles from "./styles.module.scss";

const TableTag = ({ children, className, ...rest }) => {
  return (
    <span className={`${styles.tag} ${className}`} {...rest}>
      {children}
    </span>
  );
};
export default TableTag;
