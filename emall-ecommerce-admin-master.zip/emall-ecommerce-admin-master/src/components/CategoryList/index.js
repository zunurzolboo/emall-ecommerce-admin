import React from 'react';
import { Button } from 'antd';
import { SortableContainer } from 'react-sortable-hoc';

import styles from './style.module.scss';
import SortableItem from './SortableItem';

const CategoryList = props => {
  const { onNew, onSelect, onEdit, onRemove, items, selected, index, ...rest } = props;

  return (
    <div>
      <div className={styles.action}>
        <Button onClick={onNew}>
          Нэмэх
        </Button>
      </div>
      <div className={styles.stylizedList}>
        {items.map((item, index) => {
          return (
            <SortableItem
              key={index}
              index={index}
              onSelect={item => {
                onSelect(item)
              }}
              onEdit={() => onEdit(item)}
              onRemove={() => onRemove(item)}
              item={item}
              isActive={selected && selected._id === item._id}
              {...rest} 
            />  
          )
        })}
      </div>
    </div>
  );
};

export default SortableContainer(CategoryList);
