import React from "react";
import { Menu } from "antd";
import { NavLink, useHistory } from "react-router-dom";
import { useSelector } from "react-redux";
import { MailOutlined, UnorderedListOutlined, AppleOutlined, TagOutlined, PushpinOutlined, AppstoreOutlined, SettingOutlined, FieldTimeOutlined } from "@ant-design/icons";

import styles from "./styles.module.scss";

const { SubMenu } = Menu;

const NavBar = () => {
  const history = useHistory();
  const user = useSelector((state) => state.auth.user || {});

  let selected = history.location.pathname.split("/")[1];

  if (selected === "settings")
    selected = history.location.pathname.split("/")[1] + "/" + history.location.pathname.split("/")[2];

  return (
    <Menu
      defaultSelectedKeys={[selected]}
      defaultOpenKeys={[history.location.pathname.split("/")[1]]}
      className={styles.menu}
      mode="inline"
      theme="light">
      <Menu.Item key="order" icon={<MailOutlined />}>
        Захиалга <NavLink to="/order" />
      </Menu.Item>
      {/* <Menu.Item key="delivery" icon={<FieldTimeOutlined />}>
        Хүргэлт <NavLink to="/delivery" />
      </Menu.Item> */}
      <Menu.Item key="product" icon={<AppstoreOutlined />}>
        Бараа бүртгэл <NavLink to="/product" />
      </Menu.Item>
      <Menu.Item key="category" icon={<UnorderedListOutlined />}>
        Ангилал <NavLink to="/category" />
      </Menu.Item>
      <Menu.Item key="brand" icon={<AppleOutlined />}>
        Бренд <NavLink to="/brand" />
      </Menu.Item>
      <Menu.Item key="tag" icon={<TagOutlined />}>
        Тааг <NavLink to="/tag" />
      </Menu.Item>
      <Menu.Item key="sale" icon={<PushpinOutlined />}>
        Хямдрал <NavLink to="/sale" />
      </Menu.Item>
      {/* <Menu.Item key="hightlight" icon={<StarOutlined />}>
        Онцлох <NavLink to="/hightlight" />
      </Menu.Item> */}
      <SubMenu key="settings" icon={<SettingOutlined />} title="Тохиргоо">
        <Menu.Item key="settings/home">Нүүр хуудас <NavLink to="/settings/home" /></Menu.Item>
        <Menu.Item key="settings/option">Төрөл хэмжээ <NavLink to="/settings/option" /></Menu.Item>
        <Menu.Item key="settings/attribute">Нөхцөл <NavLink to="/settings/attribute" /></Menu.Item>
        <Menu.Item key="settings/color">Өнгө <NavLink to="/settings/color" /></Menu.Item>
        <Menu.Item key="settings/banner">Баннер <NavLink to="/settings/banner" /></Menu.Item>
      </SubMenu>
    </Menu>
  );
};

export default NavBar;
