import PrivateRoute from "./Routes/Private";
import PublicRoute from "./Routes/Public";
import MyTable from "./MyTable";
import NavBar from "./NavBar";
import Header from "./Header";
import CategoryList from "./CategoryList";
import ImageUpload from "./ImageUpload";
import MultiImageUpload from "./MultiImageUpload";
import RowAction from "./RowAction";
import ProductItem from "./Product/Item";
import ProductModal from "./Product/Modal";
import ProductDetail from "./Product/Detail";
import ProductSwiper from "./Product/Swiper";
import * as Design from "./Design";
import GoogleMapPin from "./GoogleMapPin";

export {
  PrivateRoute,
  PublicRoute,
  NavBar,
  Header,
  MyTable,
  CategoryList,
  ImageUpload,
  MultiImageUpload,
  RowAction,
  ProductItem,
  ProductModal,
  ProductDetail,
  ProductSwiper,
  Design,
  GoogleMapPin
};
