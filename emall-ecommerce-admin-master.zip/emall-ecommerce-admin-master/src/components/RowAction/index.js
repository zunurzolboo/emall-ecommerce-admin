import React from "react";
import { Dropdown, Menu, Button } from "antd";
import { CaretDownOutlined } from "@ant-design/icons";

export default ({ actions, onClick }) => {

  return (
    <Dropdown overlay={(
      <Menu>
        {Object.keys(actions).map(key => (
          <Menu.Item key={key} onClick={() => onClick(key)}>
            {actions[key]}
          </Menu.Item>
        ))}
      </Menu>
    )} trigger={["click"]}>
      <Button>
        Үйлдэл
        <CaretDownOutlined />
      </Button>
    </Dropdown>
  );
};