import React from "react";
import styled from "styled-components";
import { tugrug } from "../../utils";
import { useHistory, Link } from "react-router-dom";
import Tags from "./Tags";
import { Button } from "antd";
import { DeleteOutlined } from "@ant-design/icons";
import queryString from "query-string";
import Skeleton from "react-loading-skeleton";
import { useSelector } from "react-redux";

export const Price = ({ item }) => {
  if (!item)
    return (
      <StyledPrice id="price" >
        <Skeleton height={25} width={100} />
      </StyledPrice>
    );

  return (
    <StyledPrice id="price">
      <span>{tugrug(item.sale ? item.sale.price : item.price)}</span>
      {item.sale && <span className="sale">{tugrug(item.price)}</span>}
    </StyledPrice>
  );
};

const ProductItem = (props) => {
  const { onAddCart, ...rest } = props;
  const history = useHistory();
  const params = queryString.parse(history.location.search);
  const { images = [] } = props.item || {};
  const item = props.item;
  const i2 = (images || []).find(a => !a.isMain) || {};

  const show = (_id) => {
    history.push({
      search: "?" + queryString.stringify({ ...params, _id })
    });
  };

  const onAdd = () => {
    if (onAddCart)
      onAddCart(props.item);
  };

  return (
    <div {...rest}>
      <Content>
        {item ? (
          <Thumb>
            <a onClick={() => show(item._id)} className="thumb">
              <img className="i1" src={item.image} alt="" />
              <img className="i2" src={i2.url} alt="" />
            </a>
          </Thumb>
        ) : (
          <Skeleton height={200} />
        )}
        <div className="section-info">
          <Tags id="tag" item={item} />
          <Price item={item} />
          <Title id="title">
            {item ? <a href="#">{item.title}</a> : <Skeleton height={15} width="80%" />}
          </Title>
          <Button className="add-cart" size="middle" onClick={onAdd} block>Сагсанд нэмэх</Button>
        </div>
      </Content>
    </div>
  );
};
const Content = styled.div`
  position: relative;
  width: 100%;
  margin-bottom: 16px;
  box-shadow: none;
  border-width: initial;
  border-style: none;
  border-color: initial;
  border-image: initial;
  border: 1px solid #ddd;
  padding: 8px;
  border-radius: 4px;
  .add-cart {
    background: #096cda;
    border-color: #0255b7;
    color: #fff;
    height: 35px;
    border-radius: 4px;
    font-size: 13px;
  }
`;
const Thumb = styled.div`
  display: inline-block;
  position: relative;
  width: 100%;
  top: 0px;
  left: 0px;
  overflow: hidden; 
  &:after {
    content: "";
    padding-top: 100%;
    display: block;
  }
  & > a {
    color: #323639;
    text-decoration: none;
    background-color: transparent;
    &:hover {
      img.i2 {
        opacity: 1;
      }
    }
    img {
      width: 100%;
      height: 100%;
      object-fit: contain;
      position: absolute;
      top: 0px;
      bottom: 0px;
      right: 0px;
      left: 0px;
      border-radius: 3px;
      &.i2 {
        opacity: 0;
        transition: all .3s ease-in-out 0s;
      }
    }
  }
`;
const Title = styled.h2`
  padding-bottom: 5px;
  margin-bottom: 5px;
  a {
    display: inline-block;
    overflow: hidden;
    max-height: 51px;
    font-size: 14px;
    line-height: 17px;
    letter-spacing: -0.5px;
    color: #333;
    vertical-align: top;
    word-wrap: break-word;
    word-break: break-all;
    &:hover {
      text-decoration: underline;
    }
  }
`;
const StyledPrice = styled.div`
  font-size: 22px;
  letter-spacing: -0.5px;
  color: #222;
  font-family: Roboto-Medium, sans-serif;
  vertical-align: middle;
  .sale {
    color: #6b7478;
    font-size: 12px;
    text-decoration: line-through;
    padding-left: 10px;
    font-size: 16px;
  }
`;

export default ProductItem;