import request from "../utils/request";

export const distributed = (data) =>
  request.get("/api/delivery/distributed", data);

export const distribute = (data) =>
  request.post("/api/delivery/distribute", data);

export const destroy = (data) =>
  request.post("/api/delivery/destroy", data);