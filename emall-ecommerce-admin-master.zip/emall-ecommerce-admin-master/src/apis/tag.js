import request from "../utils/request";

export const all = (data) =>
  request.get("/api/tag/all", data);

export const list = (data, options) =>
  request.get("/api/tag", data, options);

export const create = (data) =>
  request.post("/api/tag", data);

export const update = (data) =>
  request.put(`/api/tag/${data._id}`, data);

export const remove = (id) =>
  request.del(`/api/tag/${id}`);