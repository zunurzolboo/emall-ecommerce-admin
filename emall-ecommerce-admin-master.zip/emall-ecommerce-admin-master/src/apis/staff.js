import request from "../utils/request";

export const search = (data, options) =>
  request.get("/api/staff/search", data, options);

export const list = (data, options) =>
  request.get("/api/staff", data, options);

export const create = (data) =>
  request.post("/api/staff", data);

export const update = (data) =>
  request.put(`/api/staff/${data._id}`, data);

export const remove = (id) =>
  request.del(`/api/staff/${id}`);