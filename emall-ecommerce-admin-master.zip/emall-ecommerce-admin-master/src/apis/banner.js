import request from "../utils/request";

export const list = (data, options) =>
  request.get("/api/banner", data, options);

export const add = (data, options) =>
  request.post("/api/banner", data, options);