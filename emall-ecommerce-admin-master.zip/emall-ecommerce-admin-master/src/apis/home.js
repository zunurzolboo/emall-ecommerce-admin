import request from "../utils/request";

export const list = (data, options) =>
  request.get("/api/home", data, options);

export const create = (data) =>
  request.post("/api/home", data);

export const update = (data) =>
  request.put(`/api/home/${data._id}`, data);

export const remove = (id) =>
  request.del(`/api/home/${id}`);