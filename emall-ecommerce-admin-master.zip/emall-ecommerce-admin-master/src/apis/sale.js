import request from "../utils/request";

export const all = (data) =>
  request.get("/api/sale/all", data);

export const list = (data, options) =>
  request.get("/api/sale", data, options);

export const create = (data) =>
  request.post("/api/sale", data);

export const update = (data) =>
  request.put(`/api/sale/${data._id}`, data);

export const remove = (id) =>
  request.del(`/api/sale/${id}`);