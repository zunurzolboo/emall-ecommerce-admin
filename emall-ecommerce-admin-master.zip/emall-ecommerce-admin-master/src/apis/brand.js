import request from "../utils/request";

export const all = (data) =>
  request.get("/api/brand/all", data);

export const list = (data, options) =>
  request.get("/api/brand", data, options);

export const create = (data) =>
  request.post("/api/brand", data);

export const update = (data) =>
  request.put(`/api/brand/${data._id}`, data);

export const remove = (id) =>
  request.del(`/api/brand/${id}`);