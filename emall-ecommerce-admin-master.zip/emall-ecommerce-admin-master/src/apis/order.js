import request from "../utils/request";

export const status = (id, data) =>
  request.put(`/api/order/status/${id}`, data);

export const create = (data) =>
  request.post("/api/order", data);

export const list = (data, options) =>
  request.get("/api/order", data, options);

export const get = (data, options) =>
  request.get(`/api/order/${data.id}`, {}, options);