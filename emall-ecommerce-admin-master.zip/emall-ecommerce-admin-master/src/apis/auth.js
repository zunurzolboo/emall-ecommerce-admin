import request from "../utils/request";

export const login = (data) =>
  request.post("/api/auth/login", data);

export const me = () =>
  request.get("/api/me");

export const changePassword = (data) =>
  request.post("/api/user/changePassword", data);
