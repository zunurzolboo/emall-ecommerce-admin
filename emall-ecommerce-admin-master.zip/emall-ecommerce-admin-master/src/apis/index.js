import * as auth from "./auth";
import * as general from "./general";
import * as category from "./category";
import * as brand from "./brand";
import * as tag from "./tag";
import * as home from "./home";
import * as sale from "./sale";
import * as product from "./product";
import * as order from "./order";
import * as banner from "./banner";
import * as highlight from "./highlight";
import * as delivery from "./delivery";
import * as staff from "./staff";

export { auth, general, category, brand, tag, home, sale, product, order, banner, highlight, delivery, staff };
