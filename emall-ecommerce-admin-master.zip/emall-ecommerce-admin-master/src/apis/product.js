import request from "../utils/request";

export const search = (data, options) =>
  request.get("/api/product/search", data, options);

export const get = (data, options) =>
  request.get(`/api/product/${data._id}`, {}, options);

export const list = (data, options) =>
  request.get("/api/product", data, options);

export const create = (data) =>
  request.post("/api/product", data);

export const update = (data) =>
  request.put(`/api/product/${data._id}`, data);

export const remove = (id) =>
  request.del(`/api/product/${id}`);