import request from "../utils/request";

export const all = (data) =>
  request.get("/api/highlight/all", data);

export const list = (data, options) =>
  request.get("/api/highlight", data, options);

export const create = (data) =>
  request.post("/api/highlight", data);

export const update = (data) =>
  request.put(`/api/highlight/${data._id}`, data);

export const remove = (id) =>
  request.del(`/api/highlight/${id}`);