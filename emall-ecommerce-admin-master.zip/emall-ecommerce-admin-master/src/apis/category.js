import request from "../utils/request";

export const all = (data) =>
  request.get("/api/category/all", data);

export const list = (data) =>
  request.get("/api/category", data);

export const create = (data) =>
  request.post("/api/category", data);

export const update = (data) =>
  request.put(`/api/category/${data._id}`, data);

export const remove = (id) =>
  request.del(`/api/category/${id}`);