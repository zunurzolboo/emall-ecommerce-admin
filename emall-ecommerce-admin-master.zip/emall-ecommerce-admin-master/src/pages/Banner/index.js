import React from "react";
import { Tag, Modal } from "antd";
import { MyTable, RowAction } from "../../components";
import { banner } from "../../apis";
import Form from "./Form";
import { PageContainer, PageHeader, PageContent } from "../../components/Layout";
import { ExclamationCircleOutlined, PictureOutlined } from "@ant-design/icons";
import { useDispatch, useSelector } from "react-redux";

const useHeader = ({ onClick }) => ([{
  title : "Зураг",
  key   : "image",
  width : 200,
  render: record => {
    if (record.web || record.app) {
      return (
        <>
          <div style={{ marginBottom: 5 }}><img src={record.web} style={{ maxHeight: 60, width: "100%" }} /></div>
          <div><img src={record.app} style={{ maxHeight: 60, width: "100%" }} /></div>
        </>
      );
    }
    return <PictureOutlined style={{ fontSize: 22 }} />;
  }
}, {
  title    : "Нэр",
  key      : "name",
  dataIndex: "name",
}, {
  title : "Төрөл",
  key   : "type",
  render: (row) => {
    return <Tag color="red" style={{ textTransform: "uppercase" }}>{row.type}</Tag>;
  }
}, {
  title : "Идэвхтэй эсэх",
  key   : "active",
  width : 100,
  render: (row) => {
    return row.active ? <Tag color="green">Идэвхтэй</Tag> : <Tag>Идэвхгүй</Tag>;
  }
}, {
  title : "Үйлдэл",
  key   : "action",
  width : 100,
  render: (row) => {
    return <RowAction actions={{
      edit  : "Засварлах",
      remove: "Устгах"
    }} onClick={(key) => onClick(key, row)} />;
  }
}]);

export default () => {
  const [action, setAction] = React.useState(null);
  const myTableRef = React.useRef(null);
  const columns = useHeader({
    onClick: (key, item) => {
      switch (key) {
        case "edit": {
          setAction(["update", item]);
          break;
        }
        case "remove": {
          Modal.confirm({
            title  : "Баталгаажуулах",
            icon   : <ExclamationCircleOutlined />,
            content: "Та үүнийг устгахдаа итгэлтэй байна уу!",
            onOk   : async () => {
              await banner.remove(item._id);
              await myTableRef.current.reload();
            }
          });

          break;
        }
        default:
      }
    }
  });
  const onCancel = (reload) => {
    setAction(false);

    if (reload)
      myTableRef.current.reload();
  };
  const onSubmit = async (data) => {
    await banner.add(data);

    onCancel(true);
  };

  return (
    <PageContainer>
      <PageHeader>
        <h2>Баннер</h2>
      </PageHeader>

      <PageContent>
        <MyTable
          ref={myTableRef}
          rowKey={record => record.id}
          columns={columns}
          loadData={banner.list}
        />

        <Modal
          title="Баннер"
          visible={!!action}
          onCancel={() => onCancel()}
          destroyOnClose
          footer={false}>
          <Form onCancel={onCancel} action={action} onSubmit={onSubmit} />
        </Modal>
      </PageContent>
    </PageContainer>
  );
};
