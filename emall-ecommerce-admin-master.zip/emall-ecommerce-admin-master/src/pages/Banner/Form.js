import React from "react";
import { Form, FormItem, Input, Checkbox } from "formik-antd";
import { Button, Form as AntForm } from "antd";
import { Formik } from "formik";
import * as Yup from "yup";
import { formItemLayout, tailFormItemLayout } from "../../utils";
import { ImageUpload } from "../../components";
import { useSelector } from "react-redux";

const FormSchema = Yup.object().shape({
  active: Yup.boolean().optional().default(true),
  type  : Yup.string().required("Заавал бөглөнө!"),
  link  : Yup.string().required("Заавал бөглөнө!").min(2, "2-ooс дээш урттай байна!").max(100, "100-аас доош тэмдэгт оруулна уу!"),
  web   : Yup.string().required("Заавал бөглөнө!"),
  app   : Yup.string().required("Заавал бөглөнө!")
});

export default ({ action, onSubmit }) => {
  const [data] = React.useState({
    active: true,
    link  : "",
    web   : undefined,
    app   : undefined,
    ...(action && action[0] === "update" ? action[1] : {})
  });

  return (
    <div>
      <Formik
        enableReinitialize
        initialValues={data}
        validationSchema={FormSchema}
        onSubmit={onSubmit}>
        {({ isSubmitting }) => (
          <Form {...formItemLayout}>
            <FormItem name="active" label="Идэвхтэй эсэх" required>
              <Checkbox name="active" />
            </FormItem>
            <FormItem name="type" label="Төрөл" required>
              <Input name="type" disabled />
            </FormItem>
            <FormItem name="link" label="Холбоос" required>
              <Input name="link" />
            </FormItem>
            <FormItem label="Вэб" name="web" required>
              <ImageUpload action="/api/general/upload" name="web" />
            </FormItem>
            <FormItem label="Апп" name="app" required>
              <ImageUpload action="/api/general/upload" name="app" />
            </FormItem>
            <AntForm.Item {...tailFormItemLayout}>
              <Button htmlType="submit" type="primary" loading={isSubmitting} block>
                Хадгалах
              </Button>
            </AntForm.Item>
          </Form>
        )}
      </Formik>
    </div>
  );
};
