import React from "react";
import { Button, Modal } from "antd";
import { MyTable } from "../../components";
import { tag } from "../../apis";
import Form from "./Form";
import { PageContainer, PageHeader, PageContent } from "../../components/Layout";

const columns = [{
  title    : "Нэр",
  key      : "name",
  dataIndex: "name",
}];

export default () => {
  const [action, setAction] = React.useState(null);
  const myTableRef = React.useRef(null);
  const onCancel = (reload) => {
    setAction(false);

    if (reload)
      myTableRef.current.reload();
  };
  const onNew = () => {
    setAction(["create"]);
  };
  const onEdit = (data) => {
    setAction(["update", data]);
  };
  const onSubmit = async (data) => {
    if (action[0] === "create")
      await tag.create(data);
    else
      await tag.update(data._id, data);

    onCancel(true);
  };

  return (
    <PageContainer>
      <PageHeader>
        <h2>Тааг</h2>
        <div>
          <Button onClick={onNew}>Шинэ тааг</Button>
        </div>
      </PageHeader>

      <PageContent>
        <MyTable
          ref={myTableRef}
          onRow={(record) => {
            return {
              onClick: () => onEdit(record),
            };
          }}
          rowKey={record => record.id}
          columns={columns}
          loadData={tag.list}
        />

        <Modal
          title={action && action[0] === "create" ? "Тааг нэмэх" : "Тааг засах"}
          visible={!!action}
          onCancel={onCancel}
          destroyOnClose
          footer={false}>
          <Form onCancel={onCancel} action={action} onSubmit={onSubmit} />
        </Modal>
      </PageContent>
    </PageContainer>
  );
};