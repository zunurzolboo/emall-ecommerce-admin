import React from "react";
import { Form, FormItem, Input } from "formik-antd";
import { Button, Form as AntForm } from "antd";
import { Formik } from "formik";
import * as Yup from "yup";
import { formItemLayout, tailFormItemLayout } from "../../utils";

const FormSchema = Yup.object().shape({
  name: Yup.string().required("Заавал бөглөнө!").min(2, "2-ooс дээш урттай байна!").max(100, "100-аас доош тэмдэгт оруулна уу!")
});

export default ({ action, onSubmit }) => {
  const [data] = React.useState({
    name: "",
    ...(action && action[0] === "update" ? action[1] : {})
  });

  return (
    <div>
      <Formik
        enableReinitialize
        initialValues={data}
        validationSchema={FormSchema}
        onSubmit={onSubmit}>
        {({ values, errors, isSubmitting, submitForm }) => (
          <Form {...formItemLayout}>
            <FormItem name="name" label="Нэр" required>
              <Input name="name" />
            </FormItem>
            <AntForm.Item {...tailFormItemLayout}>
              <Button htmlType="submit" type="primary" loading={isSubmitting} block>
                Хадгалах
              </Button>
            </AntForm.Item>
          </Form>
        )}
      </Formik>
    </div>
  );
};
