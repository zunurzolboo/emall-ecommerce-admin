import React from "react";
import { Tag } from "antd";
import { MyTable } from "../../components";
import { delivery } from "../../apis";
import { PageContainer, PageHeader, PageContent } from "../../components/Layout";
import { useSelector } from "react-redux";
import { tugrug } from "../../utils";
import { Link, useHistory, useParams } from "react-router-dom";
import moment from "moment";
import { RowAction } from "../../components";

export default () => {
  const { deliveryStatus } = useSelector(state => state.general);
  const history = useHistory();
  const myTableRef = React.useRef(null);
  const params = useParams();
  const columns = useHeader({
    deliveryStatus,
    onClick: (key, order) => {
      switch (key) {
        case "detail": {
          history.push(`/order/detail/${order._id}`);
          break;
        }
        default:
      }
    }
  });

  return (
    <PageContainer>
      <PageHeader>
        <h2>Хувиарласан</h2>
      </PageHeader>

      <PageContent>
        <MyTable
          ref={myTableRef}
          rowKey={record => record.id}
          filters={params}
          columns={columns}
          loadData={delivery.distributed}
        />
      </PageContent>
    </PageContainer>
  );
};

// deliveryStatus    ,
// deliveryStatusDate,
// deliveryStatusName,
// additional        ,
// location          ,
// staff             ,

const useHeader = ({ deliveryStatus, onClick }) => {
  return [{
    title : "#",
    key   : "orderEm",
    render: (delivery) => {
      return <Link to={`/order/detail/${delivery._id}`}>{delivery.orderEm}</Link>;
    }
  }, {
    title    : "Нэр",
    key      : "name",
    dataIndex: "shipping",
    render   : (shipping) => {
      return `${shipping.lastName || ""} ${shipping.firstName || ""}`;
    },
  }, {
    title    : "Утас",
    key      : "phone",
    dataIndex: "shipping",
    render   : (shipping) => {
      return `${shipping.phone} ${shipping.tel || ""}`;
    }
  }, {
    title    : "Хаяг",
    key      : "address",
    dataIndex: "shipping",
    render   : (shipping) => {
      return <span>{shipping.provinceName} {shipping.districtName} {shipping.quarterName}, {shipping.address}</span>;
    }
  }, {
    title    : "Нэмэлт тайлбар",
    key      : "additional",
    dataIndex: "additional"
  }, {
    title : "Төлөв",
    key   : "status",
    render: (delivery) => {
      const status = deliveryStatus[delivery.deliveryStatus];

      if (!status) return;

      return (
        <Tag color={status.color}>{delivery.deliveryStatusName}</Tag>
      );
    }
  }, {
    title : "Төлөх дүн",
    key   : "payAmount",
    render: (order) => {
      return tugrug(order.payAmount);
    }
  }, {
    title : "Огноо",
    key   : "date",
    render: (delivery) => {
      return <span>{moment(delivery.createdAt).format("YYYY-MM-DD HH:mm:ss")}</span>;
    }
  }, {
    title : "Үйлдэл",
    key   : "action",
    render: (order) => {
      return <RowAction actions={{
        detail: "Дэлгэрэнгүй",
      }} onClick={(key) => onClick(key, order)} />;
    }
  }];
};