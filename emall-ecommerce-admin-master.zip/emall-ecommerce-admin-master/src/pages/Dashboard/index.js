import React from "react";
import { Input as AntInputNumber } from "antd";

const Dashboard = () => {
  return (
    <div className="qp-box">
      <div className="qp-card qp-box">
        <AntInputNumber allowClear prefix="￥" suffix="RMB" />
      </div>
    </div>
  );
};
export default Dashboard;
