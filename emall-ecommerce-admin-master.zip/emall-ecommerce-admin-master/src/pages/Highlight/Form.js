import React from "react";
import { Form, FormItem, Input, Checkbox } from "formik-antd";
import { Button, Form as AntForm } from "antd";
import { Formik } from "formik";
import * as Yup from "yup";
import { formItemLayout, tailFormItemLayout } from "../../utils";
import { ImageUpload } from "../../components";

const FormSchema = Yup.object().shape({
  active: Yup.boolean().optional().default(true),
  name  : Yup.string().required("Заавал бөглөнө!").min(2, "2-ooс дээш урттай байна!").max(100, "100-аас доош тэмдэгт оруулна уу!"),
  icon  : Yup.string().required("Заавал бөглөнө!")
});

export default ({ action, onSubmit }) => {
  const [data] = React.useState({
    name: "",
    ...(action && action[0] === "update" ? action[1] : {})
  });

  return (
    <div>
      <Formik
        enableReinitialize
        initialValues={data}
        validationSchema={FormSchema}
        onSubmit={onSubmit}>
        {({ isSubmitting }) => (
          <Form {...formItemLayout}>
            <FormItem name="active" label="Идэвхтэй эсэх" required>
              <Checkbox name="active" />
            </FormItem>
            <FormItem name="name" label="Нэр" required>
              <Input name="name" />
            </FormItem>
            <FormItem label="Айкон" name="icon" required>
              <ImageUpload action="/api/general/upload" name="icon" />
            </FormItem>
            <AntForm.Item {...tailFormItemLayout}>
              <Button htmlType="submit" type="primary" loading={isSubmitting} block>
                Хадгалах
              </Button>
            </AntForm.Item>
          </Form>
        )}
      </Formik>
    </div>
  );
};
