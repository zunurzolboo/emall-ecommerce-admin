import React from "react";
import Form from "./Form";
import { PageContainer, PageHeader, PageContent } from "../../components/Layout";

export default () => {
  const action = ["create"];

  return (
    <PageContainer>
      <PageHeader>
        <h2>Бараа нэмэх</h2>
      </PageHeader>

      <PageContent>
        <Form action={action} />
      </PageContent>
    </PageContainer>
  );
};
