import React from "react";
import { useHistory, Link } from "react-router-dom";
import { Button, Modal, Input } from "antd";
import { MyTable, RowAction } from "../../components";
import { product } from "../../apis";
import { ExclamationCircleOutlined } from "@ant-design/icons";
import {
  PageContainer,
  PageHeader,
  PageContent,
  PageFilter,
} from "../../components/Layout";

const { Search } = Input;

export default () => {
  const history = useHistory();
  const myTableRef = React.useRef(null);
  const [filters, setFilters] = React.useState({
    query: "",
  });
  const [query, setQuery] = React.useState("");

  const columns = useHeader({
    history,
    onClick: (key, item) => {
      switch (key) {
        case "edit": {
          history.push(`/product/${item._id}`);
          break;
        }
        case "remove": {
          Modal.confirm({
            title: "Баталгаажуулах",
            icon: <ExclamationCircleOutlined />,
            content: "Та үүнийг устгахдаа итгэлтэй байна уу!",
            onOk: async () => {
              await product.remove(item._id);
              await myTableRef.current.reload();
            },
          });

          break;
        }
        default:
      }
    },
  });

  const onChange = (e) => {
    console.log(">>>", e);
    setQuery(e.target.value);
  };

  let timer;

  React.useEffect(() => {
    if (timer) clearTimeout(timer);

    timer = setTimeout(() => {
      setFilters({ ...filters, query });
    }, 300);

    return () => {
      if (timer) clearTimeout(timer);
    };
  }, [query]);

  return (
    <PageContainer>
      <PageHeader>
        <h2>Бараанууд </h2>
        <Link to="/product/new">
          <Button>Шинэ бараа</Button>
        </Link>
      </PageHeader>

      <PageFilter>
        <Search
          type="text"
          style={{ width: 300 }}
          onChange={onChange}
          placeholder="Эндээс бүхнийг хайж олох..."
        />
      </PageFilter>

      <PageContent>
        <MyTable
          ref={myTableRef}
          rowKey={(record) => record.id}
          columns={columns}
          loadData={product.list}
          filters={filters}
        />
      </PageContent>
    </PageContainer>
  );
};

const useHeader = ({ onClick }) => {
  return [
    {
      title: "Зураг",
      render: (record) => {
        return <img src={record.image} width={120} alt={record.title} />;
      },
    },
    {
      title: "Дотоод код",
      render: (record) => {
        return <b>{record.code}</b>;
      },
    },
    {
      title: "Үнэ",
      render: (record) => {
        return (
          <div>
            <b>{record.price}</b>
            <i>{record.isFreeShipping}</i> - <i>{record.isNewGoods}</i> -
            <i>{record.isHighlight}</i> - <i>{record.sale}</i>
          </div>
        );
      },
    },
    {
      title: "Гарчиг",
      render: (record) => {
        return <Link to={`/product/${record._id}`}>{record.title}</Link>;
      },
    },
    {
      title: "Ангилал",
      render: (record) => {
        return <a>{record.category.name}</a>;
      },
    },
    {
      title: "Үйлдэл",
      key: "action",
      width: 100,
      render: (order) => {
        return (
          <RowAction
            actions={{
              edit: "Засварлах",
              remove: "Устгах",
            }}
            onClick={(key) => onClick(key, order)}
          />
        );
      },
    },
  ];
};
