import React from "react";
import { Form, FormItem, Cascader, Input, Select, InputNumber, Checkbox } from "formik-antd";
import { Button, Form as AntForm } from "antd";
import { Formik } from "formik";
import * as Yup from "yup";
import { formItemLayout, tailFormItemLayout } from "../../utils";
import { MultiImageUpload } from "../../components";
import { useSelector, useDispatch } from "react-redux";
import { product } from "../../apis";
import { useHistory } from "react-router-dom";
import useFetch from "../../hooks/useFetch";
import { category, brand, sale, tag } from "../../apis";

const FormSchema = Yup.object().shape({
  active    : Yup.boolean().optional().default(true),
  categories: Yup.array().of(Yup.string().required()).min(1).required("Заавал бөглөнө!"),
  code      : Yup.string()
    .required("Заавал бөглөнө!")
    .min(2, "2-ooс дээш урттай байна!")
    .max(100, "100-аас доош тэмдэгт оруулна уу!"),
  title: Yup.string()
    .required("Заавал бөглөнө!")
    .min(2, "2-ooс дээш урттай байна!")
    .max(100, "100-аас доош тэмдэгт оруулна уу!"),
  desc          : Yup.string().max(500, "2000-аас доош тэмдэгт оруулна уу!").required("Заавал бөглөнө!"),
  body          : Yup.string().max(4000, "2000-аас доош тэмдэгт оруулна уу!").required("Заавал бөглөнө!"),
  brand         : Yup.string().required("Заавал бөглөнө!"),
  price         : Yup.number().required("Заавал бөглөнө!"),
  isNewGoods    : Yup.boolean().optional().default(false),
  isFreeShipping: Yup.boolean().optional().default(false),
  isHighlight   : Yup.boolean().optional().default(false),
  isSale        : Yup.boolean().optional().default(false),
  sale          : Yup.object().when("isSale", {
    is  : true,
    then: Yup.object().shape({
      saleType: Yup.string().required("Заавал бөглөнө!"),
      price   : Yup.number().required("Заавал бөглөнө!")
    }).required("Заавал бөглөнө!")
  }),
  quantity: Yup.number().required("Заавал бөглөнө!"),
  tags    : Yup.array().of(Yup.string()).optional("Заавал биш!"),
  images  : Yup.array().of(Yup.string()).required("Заавал бөглөнө!")
});

export default ({ action }) => {
  const dispatch = useDispatch();
  const history = useHistory();
  const { categories } = useSelector(state => state.general);
  const [brands] = useFetch(brand.all)([]);
  const [tags] = useFetch(tag.all)([]);
  const [sales] = useFetch(sale.all)([]);

  const [data] = React.useState({
    active        : true,
    code          : undefined,
    categories    : undefined,
    tags          : undefined,
    title         : "",
    desc          : "",
    body          : "",
    brand         : undefined,
    price         : undefined,
    isFreeShipping: false,
    isNewGoods    : false,
    isHighlight   : false,
    isSale        : false,
    sale          : {
      saleType: undefined,
      price   : undefined
    },
    quantity: undefined,
    images  : undefined,
    ...(action[1] ? {
      ...action[1],
      isSale: !!action[1].sale
    } : {})
  });

  const onSubmit = async (values) => {
    let data = values;

    if (values.isSale === false)
      data.sale = undefined;

    if (action && action[0] === "create") {
      await product.create(data);
    } else {
      await product.update(data);
    }

    history.push("/product");
  };

  React.useEffect(() => {
    let asyncFn = async () => {
      let res = await category.list();

      dispatch({
        type   : "general/category",
        payload: res
      });
    };

    asyncFn();
  }, []);

  return (
    <Formik
      enableReinitialize
      initialValues={data}
      validationSchema={FormSchema}
      onSubmit={onSubmit}>
      {({ values, isSubmitting, submitForm }) => (
        <Form {...formItemLayout}>
          <FormItem name="active" label="Идэвхтэй эсэх" required>
            <Checkbox name="active" />
          </FormItem>
          <FormItem name="categories" label="Ангилал" required>
            <Cascader fieldNames={{ label: "name", value: "_id" }} options={categories} name="categories" />
          </FormItem>
          <FormItem name="code" label="Дотоод код" required>
            <Input name="code" />
          </FormItem>
          <FormItem name="title" label="Гарчиг" required>
            <Input name="title" />
          </FormItem>
          <FormItem name="desc" label="Товч тайлбар" required>
            <Input.TextArea name="desc" />
          </FormItem>
          <FormItem name="body" label="Дэлгэрэнгүй" required>
            <Input.TextArea name="body" />
          </FormItem>
          <FormItem name="brand" label="Бренд" required>
            <Select showSearch name="brand" placeholder="Сонгох">
              {brands.map(entry => (
                <Select.Option key={entry._id} value={entry._id}>
                  {entry.name}
                </Select.Option>
              ))}
            </Select>
          </FormItem>
          <FormItem name="tag" label="Тааг">
            <Select
              name="tags"
              mode="multiple"
              filterOption={(input, option) => option.props.children.toLowerCase()
                .indexOf(input.toLowerCase()) >= 0}
              placeholder="Сонгох">
              {tags.map(tag => (
                <Select.Option key={tag._id} value={tag._id}>
                  {tag.name}
                </Select.Option>
              ))}
            </Select>
          </FormItem>
          <FormItem name="price" label="Үнэ" required>
            <InputNumber name="price" />
          </FormItem>
          <FormItem name="isFreeShipping" label="Хүргэлт үнэгүй эсэх" required>
            <Checkbox name="isFreeShipping" />
          </FormItem>
          <FormItem name="isNewGoods" label="Шинэ эсэх" required>
            <Checkbox name="isNewGoods" />
          </FormItem>
          <FormItem name="isHighlight" label="Онцлох эсэх" required>
            <Checkbox name="isHighlight" />
          </FormItem>
          <FormItem name="isSale" label="Хямдралтай эсэх" required>
            <Checkbox name="isSale" />
          </FormItem>
          {values.isSale === true && (<>
            <FormItem name="sale.saleType" label="Хямдрал" required>
              <Select showSearch name="sale.saleType" placeholder="Сонгох">
                {sales.map(entry => (
                  <Select.Option key={entry._id} value={entry._id}>
                    {entry.name}
                  </Select.Option>
                ))}
              </Select>
            </FormItem>
            <FormItem name="sale.price" label="Хямдарсан үнэ" required>
              <InputNumber name="sale.price" />
            </FormItem>
          </>)}
          <FormItem name="quantity" label="Тоо ширхэг" required>
            <InputNumber name="quantity" />
          </FormItem>
          <FormItem label="Зураг" name="images" required>
            <MultiImageUpload action="/api/general/upload" name="images" />
          </FormItem>
          <AntForm.Item {...tailFormItemLayout}>
            <Button htmlType="submit" type="primary" loading={isSubmitting} block>
              Хадгалах
            </Button>
          </AntForm.Item>
        </Form>
      )}
    </Formik>
  );
};
