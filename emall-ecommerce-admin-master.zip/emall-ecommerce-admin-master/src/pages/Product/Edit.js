import React from "react";
import { useParams } from "react-router-dom";
import Form from "./Form";
import { product } from "../../apis";
import { PageContainer, PageHeader, PageContent } from "../../components/Layout";

export default () => {
  const params = useParams();
  const [loading, setLoading] = React.useState(false);
  const [action, setAction] = React.useState(["update", null]);

  const reload = React.useCallback(
    async (signal) => {
      let res = await product.get({ _id: params.id }, { signal });

      setAction(["update", res]);
      setLoading(true);
    },
    [params.id]
  );

  React.useEffect(() => {
    const abortController = new AbortController();
    const signal = abortController.signal;

    reload(signal);

    return () => abortController.abort();
  }, [reload]);

  return (
    <PageContainer>
      <PageHeader>
        <h2>Бараа засварлах</h2>
      </PageHeader>

      <PageContent>
        {loading && <Form action={action} />}
      </PageContent>
    </PageContainer>
  );
};
