import React from "react";
import { Form, FormItem, Input, Radio, DatePicker, Checkbox, Select } from "formik-antd";
import { ImageUpload } from "../../components";
import { Button, Form as AntForm } from "antd";
import { Formik } from "formik";
import * as Yup from "yup";
import { formItemLayout, tailFormItemLayout } from "../../utils";
import { useSelector } from "react-redux";

const FormSchema = Yup.object().shape({
  active   : Yup.boolean().optional().default(true),
  avatar   : Yup.string().required("Заавал бөглөнө!"),
  firstName: Yup.string().required("Заавал бөглөнө!").max(100),
  lastName : Yup.string().required("Заавал бөглөнө!").max(100),
  phone    : Yup.number().required("Заавал бөглөнө!").min(10000000).max(99999999),
  email    : Yup.string().required("Заавал бөглөнө!").max(100),
  gender   : Yup.string().required("Заавал бөглөнө!"),
  birthDay : Yup.string().required("Заавал бөглөнө!")
});

export default ({ action, onSubmit }) => {
  const { staffRoles } = useSelector(state => state.general);
  const [data] = React.useState({
    active   : true,
    avatar   : undefined,
    firstName: undefined,
    lastName : undefined,
    phone    : undefined,
    email    : undefined,
    gender   : undefined,
    birthDay : undefined,
    address  : undefined,
    ...(action && action[0] === "update" ? action[1] : {})
  });

  return (
    <div>
      <Formik
        enableReinitialize
        initialValues={data}
        validationSchema={FormSchema}
        onSubmit={onSubmit}>
        {({ isSubmitting }) => (
          <Form {...formItemLayout}>
            <FormItem name="active" label="Идэвхтэй эсэх" required>
              <Checkbox name="active" />
            </FormItem>
            <FormItem label="Зураг" name="avatar" required>
              <ImageUpload action="/api/general/upload" name="avatar" />
            </FormItem>
            <FormItem name="role" label="Хандах эрх" required>
              <Select showSearch name="role" placeholder="Сонгох">
                {staffRoles.map(entry => (
                  <Select.Option key={entry.code} value={entry.code}>
                    {entry.name}
                  </Select.Option>
                ))}
              </Select>
            </FormItem>
            <FormItem label="Овог" name="lastName" required>
              <Input size="large" name="lastName" placeholder="Овог" />
            </FormItem>
            <FormItem label="Нэр" name="firstName" required>
              <Input size="large" name="firstName" placeholder="Нэр" />
            </FormItem>
            <FormItem label="Утасны дугаар" name="phone" required>
              <Input size="large" name="phone" placeholder="Утасны дугаар" />
            </FormItem>
            <FormItem label="Имэйл" name="email" required>
              <Input size="large" name="email" placeholder="Имэйл" />
            </FormItem>
            <Form.Item label="Хүйс" name="gender" required>
              <Radio.Group name="gender">
                <Radio value="male">Эрэгтэй</Radio>
                <Radio value="female">Эмэгтэй</Radio>
              </Radio.Group>
            </Form.Item>
            <Form.Item label="Төрсөн өдөр" name="birthDay" required>
              <DatePicker name="birthDay" placeholder="Сонгох" />
            </Form.Item>
            <Form.Item label="Хаяг" name="address" required>
              <Input.TextArea name="address" placeholder="Хаяг" />
            </Form.Item>
            <AntForm.Item {...tailFormItemLayout}>
              <Button htmlType="submit" type="primary" loading={isSubmitting}>Хадгалах</Button>
            </AntForm.Item>
          </Form>
        )}
      </Formik>
    </div>
  );
};
