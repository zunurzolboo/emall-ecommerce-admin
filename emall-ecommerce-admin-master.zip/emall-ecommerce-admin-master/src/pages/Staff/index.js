import React from "react";
import { Button, Modal, Tag } from "antd";
import { MyTable } from "../../components";
import { staff } from "../../apis";
import Form from "./Form";
import { PageContainer, PageHeader, PageContent } from "../../components/Layout";
import { RowAction } from "../../components";
import { ExclamationCircleOutlined } from "@ant-design/icons";

const useHeader = ({ onClick }) => ([{
  title : "Зураг",
  key   : "image",
  width : 100,
  render: (row) => {
    return (<img width="100%" src={row.image} />);
  }
}, {
  title : "Нэр",
  key   : "name",
  render: (row) => {
    return (<span>{row.lastName} {row.firstName}</span>);
  }
}, {
  title    : "Утас",
  key      : "phone",
  dataIndex: "phone",
}, {
  title    : "Имэйл",
  key      : "email",
  dataIndex: "email",
}, {
  title    : "Хаяг",
  key      : "address",
  dataIndex: "address"
}, {
  title : "Идэвхтэй эсэх",
  key   : "active",
  render: (row) => {
    return (<Tag color={row.active ? "green" : "red"}>{row.active ? "Идэвхтэй" : "Идэвхгүй"}</Tag>);
  },
}, {
  title : "Үйлдэл",
  key   : "action",
  width : 100,
  render: (row) => {
    return <RowAction actions={{
      edit  : "Засварлах",
      remove: "Устгах"
    }} onClick={(key) => onClick(key, row)} />;
  }
}]);

export default () => {
  const [action, setAction] = React.useState(null);
  const myTableRef = React.useRef(null);
  const columns = useHeader({
    onClick: (key, item) => {
      switch (key) {
        case "edit": {
          setAction(["update", item]);
          break;
        }
        case "remove": {
          Modal.confirm({
            title  : "Баталгаажуулах",
            icon   : <ExclamationCircleOutlined />,
            content: "Та үүнийг устгахдаа итгэлтэй байна уу!",
            onOk   : async () => {
              await staff.remove(item._id);
              await myTableRef.current.reload();
            }
          });

          break;
        }
        default:
      }
    }
  });
  const onCancel = (reload) => {
    setAction(false);

    if (reload)
      myTableRef.current.reload();
  };
  const onNew = () => {
    setAction(["create"]);
  };
  const onSubmit = async (data) => {
    if (action[0] === "create")
      await staff.create(data);
    else
      await staff.update(data);

    onCancel(true);
  };

  return (
    <PageContainer>
      <PageHeader>
        <h2>Хүргэлтийн ажилтан</h2>
        <div>
          <Button onClick={onNew}>Шинэ ажилтан</Button>
        </div>
      </PageHeader>

      <PageContent>
        <MyTable
          ref={myTableRef}
          rowKey={record => record.id}
          columns={columns}
          loadData={staff.list}
        />

        <Modal
          title={action && action[0] === "create" ? "Хүргэлтийн ажилтан нэмэх" : "Хүргэлтийн ажилтан засах"}
          visible={!!action}
          onCancel={() => onCancel()}
          destroyOnClose
          footer={false}>
          <Form onCancel={onCancel} action={action} onSubmit={onSubmit} />
        </Modal>
      </PageContent>
    </PageContainer>
  );
};