import React from "react";
import { Modal, Row, Col } from "antd";
import { PageContainer, PageHeader, PageContent } from "../../components/Layout";
import Form from "./Form";
import { CategoryList } from "../../components";
import { useDispatch, useSelector } from "react-redux";
import { category } from "../../apis";
import useFetch from "../../hooks/useFetch";

export default () => {
  const dispatch = useDispatch();
  const { categories } = useSelector(state => state.general);
  const [action, setAction] = React.useState(null);
  const [columns, setColumns] = React.useState([{
    parent  : "rootElement",
    children: categories
  }]);
  const onNew = (parents = []) => {
    setAction(["create", ["rootElement", ...parents]]);
  };
  const onEdit = (data) => {
    setAction(["update", data]);
  };
  const onRemove = async (item) => {
    await category.remove(item._id);
    await loadResults();
  };
  const onSelect = (item, index) => {
    loadColumns(item, index);
  };
  const onSorted = () => {};
  const onCancel = async (isReload) => {
    if (isReload === true) {
      await loadResults();
    }

    setAction(false);
  };
  const loadColumns = async (item, index) => {
    let array = columns.slice(0, index + 1);

    array[index] = { ...array[index], selected: item };

    if (item && item.children && item.children.length > 0)
      array.push({
        parents : [...item.parents, item._id],
        children: item.children
      });

    setColumns(array);
  };
  const loadResults = async (signal) => {
    let res = await category.list(null, { signal });

    dispatch({
      type   : "general/category",
      payload: res
    });
  };

  const init = React.useCallback(async (signal) => {
    loadResults(signal);
  }, []);

  React.useEffect(() => {
    setColumns([{
      parent  : "rootElement",
      children: categories
    }]);

    const abortController = new AbortController();
    const signal = abortController.signal;

    if (categories.length === 0)
      init(signal);

    return () => abortController.abort();
  }, [categories]);

  return (
    <PageContainer>
      <PageHeader>
        <h2>Ангилал</h2>
      </PageHeader>

      <PageContent>
        <Row>
          {columns.map((column, index) => (
            <Col key={index} span={6}>
              <CategoryList
                key={index}
                items={column.children}
                selected={column.selected}
                onNew={() => onNew(column.parents)}
                onEdit={onEdit}
                onRemove={item => onRemove(item, index)}
                onSelect={item => onSelect(item, index)}
                onSortEnd={({ oldIndex, newIndex }) => onSorted(oldIndex, newIndex, undefined)}
                useDragHandle
              />
            </Col>
          ))}
        </Row>

        <Modal
          title={action && action[0] === "create" ? "Ангилал нэмэх" : "Ангилал засах"}
          visible={!!action}
          onCancel={onCancel}
          destroyOnClose
          footer={false}>
          <Form onCancel={onCancel} action={action} />
        </Modal>
      </PageContent>
    </PageContainer>
  );
};
