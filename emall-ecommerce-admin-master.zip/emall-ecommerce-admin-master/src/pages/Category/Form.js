import React from "react";
import { Form, FormItem, Cascader, Input, Checkbox } from "formik-antd";
import { Form as AntForm, Button } from "antd";
import { Formik } from "formik";
import { formItemLayout, tailFormItemLayout } from "../../utils";
import * as Yup from "yup";
import { ImageUpload } from "../../components";
import { category } from "../../apis";
import { useSelector } from "react-redux";

const FormSchema = Yup.object().shape({
  isActive: Yup.boolean(),
  parents : Yup.array().of(Yup.string().required("Must be string")).required(),
  name    : Yup.string()
    .required("Нэрийг заавал оруулна!")
    .min(2, "2-ooс дээш урттай байна")
    .max(100, "100-аас доош тэмдэгт оруулна уу"),
  icon : Yup.string().optional().nullable(),
  image: Yup.string().optional().nullable()
});

export default ({ onCancel, action }) => {
  const categories = useSelector(state => state.general.categories);
  const [data] = React.useState({
    isActive: true,
    parents : action[1],
    name    : "",
    icon    : null,
    image   : null,
    ...(action && action[0] === "update" ? {
      ...action[1],
      parents: ["rootElement", ...action[1].parents]
    } : {})
  });

  const onSubmit = async (data) => {
    if (action[0] === "create")
      await category.create(data);
    else
      await category.update(data);

    onCancel(true);
  };

  return (
    <Formik
      enableReinitialize
      initialValues={data}
      validationSchema={FormSchema}
      onSubmit={onSubmit}>
      {({ values, errors, isSubmitting, submitForm }) => (
        <Form {...formItemLayout}>
          <FormItem name="isActive" label="Идэвхтэй эсэх" required>
            <Checkbox name="isActive" />
          </FormItem>
          <FormItem label='Ангилал' name='category' hasFeedback>
            <Cascader
              name='parents'
              placeholder='Сонгох'
              changeOnSelect
              fieldNames={{
                value   : "_id",
                label   : "name",
                children: "children"
              }}
              options={[{
                _id     : "rootElement",
                name    : "Үндсэн",
                children: categories
              }]}
            />
          </FormItem>
          <FormItem label='Нэр' name='name' hasFeedback required>
            <Input name='name' placeholder='Нэр' />
          </FormItem>
          <FormItem label='Icon' name='icon' hasFeedback>
            <ImageUpload name='icon' action="/api/general/upload" />
          </FormItem>
          <FormItem label='Зураг' name='image' hasFeedback>
            <ImageUpload name='image' action="/api/general/upload" />
          </FormItem>
          <AntForm.Item {...tailFormItemLayout} style={{ marginTop: 20 }}>
            <Button htmlType="submit" type="primary" loading={isSubmitting} style={{ marginRight: 10 }}>Хадгалах</Button>
            <Button type="link" onClick={onCancel}>Болих</Button>
          </AntForm.Item>
        </Form>
      )}
    </Formik>
  );
};
