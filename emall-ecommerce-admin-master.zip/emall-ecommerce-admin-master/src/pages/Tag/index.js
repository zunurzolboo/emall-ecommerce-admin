import React from "react";
import { Button, Modal } from "antd";
import { MyTable } from "../../components";
import { tag } from "../../apis";
import Form from "./Form";
import { PageContainer, PageHeader, PageContent } from "../../components/Layout";
import { RowAction } from "../../components";
import { ExclamationCircleOutlined } from "@ant-design/icons";

const useHeader = ({ onClick }) => ([{
  title    : "Нэр",
  key      : "name",
  dataIndex: "name",
}, {
  title : "Үйлдэл",
  key   : "action",
  width : 100,
  render: (row) => {
    return <RowAction actions={{
      edit  : "Засварлах",
      remove: "Устгах"
    }} onClick={(key) => onClick(key, row)} />;
  }
}]);

export default () => {
  const [action, setAction] = React.useState(null);
  const myTableRef = React.useRef(null);
  const columns = useHeader({
    onClick: (key, item) => {
      switch (key) {
        case "edit": {
          setAction(["update", item]);
          break;
        }
        case "remove": {
          Modal.confirm({
            title  : "Баталгаажуулах",
            icon   : <ExclamationCircleOutlined />,
            content: "Та үүнийг устгахдаа итгэлтэй байна уу!",
            onOk   : async () => {
              await tag.remove(item._id);
              await myTableRef.current.reload();
            }
          });

          break;
        }
        default:
      }
    }
  });
  const onCancel = (reload) => {
    setAction(false);

    if (reload)
      myTableRef.current.reload();
  };
  const onNew = () => {
    setAction(["create"]);
  };
  const onSubmit = async (data) => {
    if (action[0] === "create")
      await tag.create(data);
    else
      await tag.update(data);

    onCancel(true);
  };

  return (
    <PageContainer>
      <PageHeader>
        <h2>Тааг</h2>
        <div>
          <Button onClick={onNew}>Шинэ тааг</Button>
        </div>
      </PageHeader>

      <PageContent>
        <MyTable
          ref={myTableRef}
          rowKey={record => record.id}
          columns={columns}
          loadData={tag.list}
        />

        <Modal
          title={action && action[0] === "create" ? "Тааг нэмэх" : "Тааг засах"}
          visible={!!action}
          onCancel={() => onCancel()}
          destroyOnClose
          footer={false}>
          <Form onCancel={onCancel} action={action} onSubmit={onSubmit} />
        </Modal>
      </PageContent>
    </PageContainer>
  );
};