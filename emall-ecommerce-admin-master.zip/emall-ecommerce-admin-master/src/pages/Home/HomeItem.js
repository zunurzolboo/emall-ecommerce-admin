import React from "react";
import { FormItem, Select, Input, Cascader } from "formik-antd";

const renderFilter = ({ filterType, tags, categories }) => {
  switch (filterType) {
    case "tag":
      return (
        <FormItem label="Tag" name="tag">
          <Select name="tag" mode="multiple">
            {tags.map(tag => (
              <Select.Option key={tag._id} value={tag._id}>
                {tag.name}
              </Select.Option>
            ))}
          </Select>
        </FormItem>
      );
    case "category": {
      return (
        <FormItem label="Ангилал" name="categories">
          <Cascader
            name="categories"
            placeholder="Сонгох"
            changeOnSelect
            fieldNames={{ value: "_id", label: "name", children: "children" }}
            options={categories}
          />
        </FormItem>
      );
    }
    default:
  }
};

export default ({ values, tags, categories }) => {
  return (
    <>
      <FormItem label="Гарчиг" name="title">
        <Input name="title" placeholder="Гарчиг" />
      </FormItem>
      <FormItem label="Холбоос" name="link">
        <Input name="link" placeholder="Холбоос" />
      </FormItem>
      <FormItem label="Холбоос нэр" name="linkText">
        <Input name="linkText" placeholder="Холбоос нэр" />
      </FormItem>
      <FormItem label="Төрөл" name="filterType">
        <Select name="filterType">
          <Select.Option value="tag">Тааг</Select.Option>
          <Select.Option value="category">Ангилал</Select.Option>
        </Select>
      </FormItem>
      {renderFilter({ filterType: values.filterType, tags, categories })}
    </>
  );
};