import React from "react";
import { Button, Modal, Popconfirm } from "antd";
import { MyTable } from "../../components";
import { home } from "../../apis";
import Form from "./Form";
import { RowAction } from "../../components";
import { PageContainer, PageHeader, PageContent } from "../../components/Layout";
import { useHistory } from "react-router-dom";
import { ExclamationCircleOutlined } from "@ant-design/icons";

const useHeader = ({ onClick }) => {
  return [{
    title    : "Нэр",
    dataIndex: "name",
    key      : "name"
  }, {
    title    : "Төрөл",
    dataIndex: "type",
    key      : "type"
  }, {
    title    : "Sort",
    dataIndex: "sort",
    key      : "sort",
    width    : 100
  }, {
    title : "Үйлдэл",
    key   : "action",
    width : 100,
    render: (row) => {
      return <RowAction actions={{
        edit  : "Засварлах",
        remove: "Устгах"
      }} onClick={(key) => onClick(key, row)} />;
    }
  }];
};

export default () => {
  const history = useHistory();
  const [action, setAction] = React.useState(null);
  const myTableRef = React.useRef(null);
  const onCancel = (reload) => {
    setAction(false);

    if (reload) {
      myTableRef.current.reload();
    }
  };
  const onNew = () => {
    setAction(["create"]);
  };
  const onSubmit = async (data) => {
    if (action[0] === "create") {
      await home.create(data);
    } else {
      await home.update(data);
    }

    onCancel(true);
  };
  const columns = useHeader({ history,
    onClick: (key, item) => {
      switch (key) {
        case "edit": {
          setAction(["update", item]);
          break;
        }
        case "remove": {
          Modal.confirm({
            title  : "Баталгаажуулах",
            icon   : <ExclamationCircleOutlined />,
            content: "Та үүнийг устгахдаа итгэлтэй байна уу!",
            onOk   : async () => {
              await home.remove(item._id);
              await myTableRef.current.reload();
            }
          });

          break;
        }
        default:
      }
    }
  });

  return (
    <PageContainer>
      <PageHeader>
        <h2>Нүүр хуудас</h2>
        <div>
          <Button onClick={onNew}>Шинэ хуудасны төрөл</Button>
        </div>
      </PageHeader>

      <PageContent>
        <MyTable
          ref={myTableRef}
          rowKey={record => record.id}
          columns={columns}
          loadData={home.list}
        />

        <Modal
          title={action && action[0] === "create" ? "Хуудасны төрөл нэмэх" : "Хуудасны төрөл засах"}
          visible={!!action}
          onCancel={() => onCancel()}
          destroyOnClose
          footer={false}>
          <Form onCancel={onCancel} action={action} onSubmit={onSubmit} />
        </Modal>
      </PageContent>
    </PageContainer>
  );
};