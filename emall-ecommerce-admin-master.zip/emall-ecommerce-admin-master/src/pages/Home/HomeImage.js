import React from "react";
import { Col, Row } from "antd";
import { FormItem, Input, InputNumber, Select } from "formik-antd";
import { FieldArray } from "formik";
import { ImageUpload } from "../../components";

export default ({ values, onChangeColumn }) => {
  return (
    <>
      <FormItem label="Багана" name="col">
        <Select
          name="col"
          onChange={value => onChangeColumn(value)}>
          <Select.Option value="1">1</Select.Option>
          <Select.Option value="2">2</Select.Option>
          <Select.Option value="3">3</Select.Option>
          <Select.Option value="4">4</Select.Option>
        </Select>
      </FormItem>
      <FormItem label="Сул зай" name="gutter">
        <InputNumber name="gutter" placeholder="0" />
      </FormItem>
      <FormItem label="Зураг" name="items[]">
        <FieldArray name="items" render={() => (
          <>
            {values.items.map((item, index) => (
              <Row key={index} gutter={20}>
                <Col md={8}>
                  <FormItem name={`items[${index}].link`}>
                    <Input name={`items[${index}].link`} placeholder="link" />
                  </FormItem>
                  <FormItem name={`items[${index}].text`}>
                    <Input name={`items[${index}].text`} placeholder="text" />
                  </FormItem>
                </Col>
                <Col md={8}>
                  <FormItem name={`items[${index}].image`}>
                    <ImageUpload action="/api/general/upload" name={`items[${index}].image`} />
                  </FormItem>
                </Col>
              </Row>
            ))}
          </>
        )}/>
      </FormItem>
    </>
  );
};