import React from "react";
import { Form, FormItem, Input, SubmitButton, InputNumber, Select } from "formik-antd";
import { useSelector } from "react-redux";
import { Formik } from "formik";
import * as Yup from "yup";
import { Button, Form as AntForm } from "antd";
import debounce from "lodash/debounce";
import { product } from "../../apis";
import HomeSlider from "./HomeSlider";
import HomeSlideshow from "./HomeSlideshow";
import HomeImage from "./HomeImage";
import HomeItem from "./HomeItem";
import styled from "styled-components";

import { formItemLayout, tailFormItemLayout } from "../../utils";

const FormSchema = Yup.object().shape({
  name: Yup.string().required("Заавал бөглөнө"),
  type: Yup.string().required("Заавал бөглөнө")
});

export default ({ action, onSubmit }) => {
  const { tags, categories } = useSelector(state => state.general);
  const [products, setProducts] = React.useState([]);
  const [fetching, setFetching] = React.useState(false);
  const [data] = React.useState({
    name      : "",
    type      : "",
    col       : "",
    gutter    : "",
    image     : "",
    products  : [],
    items     : [],
    title     : "",
    link      : "",
    linkText  : "",
    filterType: "",
    tag       : "",
    categories: [],
    sort      : 999,
    ...(action && action[0] === "update" ? action[1] : {})
  });

  const fetchProduct = async value => {
    try {
      setFetching(true);

      const res = await product.search({ search: value });

      if (res && Array.isArray(res)) {
        setProducts(
          res.map(product => ({
            text : product.title,
            value: product._id
          }))
        );
      }

      setFetching(false);
    } catch (err) {
      console.log("err:", err);
    }
  };
  const fetchDebouncedProduct = debounce(fetchProduct, 800);
  const onChangeProduct = () => {
    setFetching(false);
    setProducts([]);
  };
  const renderForm = ({ values, type, onChangeColumn }) => {
    switch (type) {
      case "HomeSlider": {
        return <HomeSlider fetching={fetching} onChangeProduct={onChangeProduct} fetchDebouncedProduct={fetchDebouncedProduct} products={products} />;
      }
      case "HomeSlideshow": {
        return <HomeSlideshow onChangeColumn={onChangeColumn} values={values} />;
      }
      case "HomeImage": {
        return <HomeImage values={values} onChangeColumn={onChangeColumn} />;
      }
      case "HomeItem": {
        return <HomeItem values={values} tags={tags} categories={categories} />;
      }
      default:
    }
  };

  return (
    <Formik
      enableReinitialize
      initialValues={data}
      validationSchema={FormSchema}
      onSubmit={onSubmit}>
      {({ values, setFieldValue, isSubmitting }) => {
        const onChangeColumn = value => {
          let items = [];
          for (let i = 0; i < parseInt(value, 10); i++) {
            items.push({
              link : "",
              text : "",
              image: ""
            });
          }
          setFieldValue("items", items);
        };

        return (
          <Form {...formItemLayout}>
            <FormItem label='Нэр' name='name' hasFeedback required>
              <Input name='name' placeholder='Нэр' />
            </FormItem>
            <FormItem label='Төрөл' name='type' hasFeedback required>
              <Select name='type' placeholder="Сонгох">
                <Select.Option value='HomeImage'>IMAGE</Select.Option>
                <Select.Option value='HomeSlideshow'>SLIDE SHOW</Select.Option>
                <Select.Option value='HomeItem'>ITEM</Select.Option>
                <Select.Option value='HomeSlider'>SLIDER</Select.Option>
              </Select>
            </FormItem>

            <Divider />

            {renderForm({ values, onChangeColumn, type: values.type })}

            <FormItem label="Sort" name="sort">
              <InputNumber name="sort" placeholder="999" />
            </FormItem>

            <AntForm.Item {...tailFormItemLayout}>
              <Button htmlType="submit" type="primary" loading={isSubmitting} block>
                Хадгалах
              </Button>
            </AntForm.Item>
          </Form>
        );
      }}
    </Formik>
  );
};
const Divider = styled.div`
  border-top: 1px dashed #ddd;
  padding-bottom: 20px;
`;
