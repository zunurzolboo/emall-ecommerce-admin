import React from "react";
import { Spin } from "antd";
import { FormItem, Select } from "formik-antd";
import { ImageUpload } from "../../components";

export default ({ fetching, onChangeProduct, fetchDebouncedProduct, products }) => {
  return (
    <>
      <FormItem name='image' label='Зураг'>
        <ImageUpload action="/api/general/upload" name='image' />
      </FormItem>
      <FormItem name='products' label='Баранууд'>
        <Select
          name='products'
          mode='multiple'
          labelInValue
          placeholder='Бараа сонгох'
          notFoundContent={fetching ? <Spin size='small' /> : null}
          filterOption={false}
          onChange={onChangeProduct}
          onSearch={fetchDebouncedProduct}>
          {products.map(d => (
            <Select.Option key={d.value} value={d.value}>
              {d.text}
            </Select.Option>
          ))}
        </Select>
      </FormItem>
    </>
  );
};