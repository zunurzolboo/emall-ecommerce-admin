import React from "react";
import { Button, Modal } from "antd";
import { MyTable, RowAction } from "../../components";
import { brand } from "../../apis";
import Form from "./Form";
import { PageContainer, PageHeader, PageContent } from "../../components/Layout";
import { ExclamationCircleOutlined } from "@ant-design/icons";
import { useDispatch } from "react-redux";

const useHeader = ({ onClick }) => ([{
  title : "Зураг",
  key   : "image",
  render: record => {
    if (record.image) {
      return <img src={record.image} style={{ height: 75, width: "auto" }} alt={record.name} />;
    }
    return null;
  }
}, {
  title    : "Нэр",
  key      : "name",
  dataIndex: "name",
}, {
  title : "Үйлдэл",
  key   : "action",
  width : 100,
  render: (row) => {
    return <RowAction actions={{
      edit  : "Засварлах",
      remove: "Устгах"
    }} onClick={(key) => onClick(key, row)} />;
  }
}]);

export default () => {
  const [action, setAction] = React.useState(null);
  const myTableRef = React.useRef(null);
  const dispatch = useDispatch();
  const columns = useHeader({
    onClick: (key, item) => {
      switch (key) {
        case "edit": {
          setAction(["update", item]);
          break;
        }
        case "remove": {
          Modal.confirm({
            title  : "Баталгаажуулах",
            icon   : <ExclamationCircleOutlined />,
            content: "Та үүнийг устгахдаа итгэлтэй байна уу!",
            onOk   : async () => {
              await brand.remove(item._id);
              await myTableRef.current.reload();
            }
          });

          break;
        }
        default:
      }
    }
  });
  const onCancel = (reload) => {
    setAction(false);

    if (reload)
      myTableRef.current.reload();
  };
  const onNew = () => {
    setAction(["create"]);
  };
  const onSubmit = async (data) => {
    if (action[0] === "create")
      await brand.create(data);
    else
      await brand.update(data);

    onCancel(true);
  };

  return (
    <PageContainer>
      <PageHeader>
        <h2>Бренд</h2>
        <div>
          <Button onClick={onNew}>Шинэ бренд</Button>
        </div>
      </PageHeader>

      <PageContent>
        <MyTable
          ref={myTableRef}
          rowKey={record => record.id}
          columns={columns}
          loadData={brand.list}
        />

        <Modal
          title={action && action[0] === "create" ? "Бренд нэмэх" : "Бренд засах"}
          visible={!!action}
          onCancel={() => onCancel()}
          destroyOnClose
          footer={false}>
          <Form onCancel={onCancel} action={action} onSubmit={onSubmit} />
        </Modal>
      </PageContent>
    </PageContainer>
  );
};
