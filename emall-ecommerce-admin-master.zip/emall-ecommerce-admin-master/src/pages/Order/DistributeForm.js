import React from "react";
import { Form, FormItem, Input, Select } from "formik-antd";
import { Button, Form as AntForm, Result, Spin, Alert } from "antd";
import { Formik } from "formik";
import * as Yup from "yup";
import { tailFormItemLayout } from "../../utils";
import debounce from "../../hooks/debounce";
import { GoogleMapPin } from "../../components";
import { staff } from "../../apis";

const FormSchema = Yup.object().shape({
  staff     : Yup.string().required("Заавал бөглөнө!"),
  additional: Yup.string().required("Заавал бөглөнө!").min(2, "2-ooс дээш урттай байна!").max(500, "500-аас доош тэмдэгт оруулна уу!"),
  location  : Yup.array().required("Заавал бөглөнө!"),
});

export default ({ action, onSubmit }) => {
  const [fetching, setFetching] = React.useState(false);
  const [staffs, setStaffs] = React.useState([]);
  const [data] = React.useState({
    staff     : undefined,
    additional: undefined,
    location  : undefined
  });

  const fetchStaff = async value => {
    setFetching(true);
    const results = await staff.search({ q: value });

    setStaffs(
      results.map(staff => ({
        label: `${staff.lastName} ${staff.firstName}`,
        value: staff._id
      }))
    );

    setFetching(false);
  };
  // const fetchDebouncedStaff = debounce(fetchStaff, 300);
  const onSelect = () => {
    setFetching(false);
    setStaffs([]);
  };

  return (
    <div>
      <Formik
        enableReinitialize
        initialValues={data}
        validationSchema={FormSchema}
        onSubmit={onSubmit}>
        {({ isSubmitting, errors, touched }) => (
          <Form layout="vertical">
            <Result
              style={{ padding: 0, marginBottom: 20 }}
              status="success"
              title="Баталгаажуулах"
              subTitle="Та нэмэлт тайлбар оруулна уу!"
            />
            <FormItem name="staff" label="Хүргэлтийн ажилтан" required>
              <Select
                name="staff"
                showSearch
                labelInValue
                placeholder="Ажилтан хайх..."
                notFoundContent={fetching ? <Spin size="small" /> : null}
                onSelect={onSelect}
                onSearch={fetchStaff}>
                {staffs.map((s, index) => (
                  <Select.Option key={index} value={s.value}>{s.label}</Select.Option>
                ))}
              </Select>
            </FormItem>
            <FormItem name="additional" label="Нэмэлт тайлбар" required>
              <Input.TextArea size="large" name="additional" />
            </FormItem>
            <FormItem noStyle name="location" label="Байршил" required>
              <GoogleMapPin name="location" />
              {errors.location && touched.location && <Alert type="error" message="Байршил оруулна уу!" banner />}
            </FormItem>
            <AntForm.Item {...tailFormItemLayout}>
              <Button htmlType="submit" size="large" type="primary" loading={isSubmitting} block>
                Баталгаажуулах
              </Button>
            </AntForm.Item>
          </Form>
        )}
      </Formik>
    </div>
  );
};
