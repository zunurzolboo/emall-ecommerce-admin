import React from "react";
import { useParams, Redirect, useHistory } from "react-router-dom";
import { order as orderApi, delivery as deliveryApi } from "../../apis";
import { PageContainer, PageContent, PageHeader } from "../../components/Layout";
import { GoogleMapPin } from "../../components";
import { Confirm } from "../../components/Design";
import { PageHeader as AntPageHeader, Descriptions, Statistic, Button, Card, Steps, Result } from "antd";
import { Row, Col, Modal } from "antd";
import styled from "styled-components";
import moment from "moment";
import { useSelector } from "react-redux";
import { tugrug } from "../../utils";
import useFetch from "../../hooks/useFetch";
import ConfirmForm from "./ConfirmForm";
import DistributeForm from "./DistributeForm";
import { notification } from "antd";

const { Step } = Steps;

const getStatus = (status) => {
  switch (status) {
    case "pending": {
      return {
        name: "Захиалага хүлээн авсан",
        step: 0,
      };
    }
    case "verified": {
      return {
        name: "Баталгаажсан",
        step: 1,
      };
    }
    case "onway": {
      return {
        name: "Хүргэлтэнд гарсан",
        step: 2,
      };
    }
    case "delivered": {
      return {
        name: "Хүргэгдсэн",
        step: 3,
      };
    }
    case "canceled": {
      return {
        name: "Захиалага цуцлагдсан",
        step: -1,
      };
    }
    default:
      return "Тодорхойгүй";
  }
};
const setNotification = (type) => {
  switch (type) {
    case "verified":
      return notification.success({
        message    : "Баталгаажуулах",
        description:
          "Захиалгыг амжилттай баталгаажуулсан.",
      });
    case "canceled":
      return notification.warning({
        message    : "Цуцлах",
        description:
          "Захиалга цуцлагдлаа!",
      });
    default:
  }
};

export default () => {
  const params = useParams();
  const [action, setAction] = React.useState(null);
  const [query, setQuery] = React.useState({ id: params.id });
  const { orderStatus, deliveryStatus } = useSelector(state => state.general);
  const [order, loading] = useFetch(orderApi.get, query)({ shipping: {}, payment: {}, carts: [], delivery: null });

  const onCancel = () => {
    setAction(null);
  };
  const onSubmit = async (values) => {
    if (action[0] === "distribute")
      await deliveryApi.distribute({
        orderId   : params.id,
        additional: values.additional,
        staff     : values.staff.value,
        location  : values.location
      });
    else
      await orderApi.status(params.id, { ...values, status: action[0] });

    setNotification(action[0]);
    setQuery({ id: params.id, time: new Date() });
    setAction(null);
  };
  const onConfirm = (action) => {
    setAction([action]);
  };

  return (
    <PageContainer>
      <PageHeader>
        <h2>Захиалга</h2>
      </PageHeader>
      <PageContent>
        <Row gutter={30}>
          <Col span={16}>
            <AntPageHeader
              title={order.orderEm}
              style={{ border: "1px solid rgb(235, 237, 240)" }}
              subTitle={`Огноо: ${moment(order.created).format("YYYY-MM-DD HH:mm")}`}>
              <Descriptions size="small" column={2}>
                <Descriptions.Item label="Овог">{order.shipping.lastName}</Descriptions.Item>
                <Descriptions.Item label="Нэр">{order.shipping.firstName}</Descriptions.Item>
                <Descriptions.Item label="Утас">{order.shipping.phone} {order.shipping.tel}</Descriptions.Item>
                <Descriptions.Item label="Цахим хаяг">{order.shipping.email}</Descriptions.Item>
                {order.orderType === "citizen" && (
                  <Descriptions.Item label="Овог">{order.shipping.lastname}</Descriptions.Item>
                )}
                {order.orderType === "citizen" && (
                  <Descriptions.Item label="Нэр">{order.shipping.firstname}</Descriptions.Item>
                )}
                {order.orderType === "company" && (
                  <Descriptions.Item label="Байгууллагын нэр">{order.shipping.companyName}</Descriptions.Item>
                )}
                {order.orderType === "company" && (
                  <Descriptions.Item label="Байгууллагын регистер">{order.shipping.companyRegister}</Descriptions.Item>
                )}
                <Descriptions.Item label="Дүүрэг">{order.shipping.districtName || "-"}</Descriptions.Item>
                <Descriptions.Item label="Хороо">{order.quarterName || "-"}</Descriptions.Item>
                <Descriptions.Item label="Байр">{order.place || "-"}</Descriptions.Item>
                <Descriptions.Item label="Орцны код">{order.placeCode || "-"}</Descriptions.Item>
                <Descriptions.Item label="Хүргэлтийн хаяг">
                  {order.shipping.provinceName} {order.shipping.districtName} {order.shipping.quarterName}, {order.shipping.address}
                </Descriptions.Item>
                <Descriptions.Item label="Төлбөрийн нөхцөл">
                  <span style={{ textTransform: "uppercase" }}>{order.payment.methodName}</span>
                </Descriptions.Item>
              </Descriptions>
              <hr />
              <div style={{ display: "flex", width: "max-content", justifyContent: "flex-end" }}>
                <Statistic title="Төлөв" value={order.payment.paymentStatusName} style={{ marginRight: 32 }} />
                <Statistic title="Хүргэлтийн нэмэгдэл" prefix="₮" value={order.deliveryAmount} />
              </div>
              {order.delivery && (
                <>
                  <hr />
                  <div style={{ display: "flex", width: "max-content", justifyContent: "flex-end" }}>
                    <Statistic title="Хүргэлтийн ажилтан" value={`${order.delivery.staff.lastName} ${order.delivery.staff.firstName}`} style={{ marginRight: 32 }} />
                    <Statistic title="Утас" value={order.delivery.staff.phone + " "} style={{ marginRight: 32 }} />
                    <Statistic title="Огноо" value={moment(order.delivery.createdAt).format("YYYY-MM-DD HH:mm")} />
                  </div>
                  <br />
                  <GoogleMapPin location={order.delivery.location} />
                </>
              )}
            </AntPageHeader>
            <br/>
            <Card bordered title="Захиалгын явц">
              {getStatus(order.orderStatus).step === -1 ? (
                <Result status="warning" title="Захиалага цуцлагдсан." />
              ) : (
                <Steps progressDot current={getStatus(order.orderStatus).step}>
                  <Step title="Захиалага хүлээн авсан" />
                  <Step title="Баталгаажсан" />
                  <Step title="Хүргэлтэнд гарсан" />
                  <Step title="Хүргэгдсэн" />
                </Steps>
              )}
            </Card>
            <br/>
            {order.operator && (
              <Card bordered title="Захиалга">
                <Descriptions size="small" column={2}>
                  <Descriptions.Item label="Оператор">{order.operator.lastName} {order.operator.firstName}</Descriptions.Item>
                  <Descriptions.Item label="Утас">{order.operator.phone}</Descriptions.Item>
                  <Descriptions.Item label="Имэйл">{order.operator.email}</Descriptions.Item>
                  <Descriptions.Item label=""></Descriptions.Item>
                  <Descriptions.Item label="Нэмэлт тайлбар">{order.operator.additional}</Descriptions.Item>
                </Descriptions>
                <hr />
                <div style={{ display: "flex", width: "max-content", justifyContent: "flex-end" }}>
                  <Statistic title="Төлөв" value={order.operator.operatorStatusName} style={{ marginRight: 32 }} />
                  <Statistic title="Огноо" value={moment(order.operator.operatorStatusDate).format("YYYY-MM-DD HH:mm")} />
                </div>
              </Card>
            )}
            <br/>
            {order.delivery && (
              <Card bordered title="Хүргэлт">
                <Descriptions size="small" column={2}>
                  <Descriptions.Item label="Оператор">{order.delivery.lastName} {order.delivery.firstName}</Descriptions.Item>
                  <Descriptions.Item label="Утас">{order.delivery.phone}</Descriptions.Item>
                  <Descriptions.Item label="Имэйл">{order.delivery.email}</Descriptions.Item>
                  <Descriptions.Item label=""></Descriptions.Item>
                  <Descriptions.Item label="Нэмэлт тайлбар">{order.delivery.additional}</Descriptions.Item>
                </Descriptions>
                <hr />
                <div style={{ display: "flex", width: "max-content", justifyContent: "flex-end" }}>
                  <Statistic title="Төлөв" value={order.delivery.deliveryStatusName} style={{ marginRight: 32 }} />
                  <Statistic title="Огноо" value={moment(order.delivery.createdAt).format("YYYY-MM-DD HH:mm")} />
                </div>
              </Card>
            )}
          </Col>
          <Col span={8}>
            <Card bordered title="Захиалгын мэдээлэл">
              <Checkout order={order} />
            </Card>

            <br />

            {(order.orderStatus === orderStatus.pending.code || order.orderStatus === orderStatus.canceled.code) && (
              <Confirm className="success">
                <Button loading={loading} size="large" onClick={() => onConfirm(orderStatus.verified.code)} block>
                  <div className="name">
                      Баталгаажуулах
                    <div>Захиалга</div>
                  </div>
                  <div className="amount">{tugrug(order.payAmount)}</div>
                </Button>
              </Confirm>
            )}

            {order.orderStatus === orderStatus.verified.code && (
              <Confirm className="danger" style={{ marginTop: 5 }}>
                <Button loading={loading} size="large" onClick={() => onConfirm(orderStatus.canceled.code)} block>
                  <div className="name">
                  Цуцлах
                    <div>Захиалга</div>
                  </div>
                </Button>
              </Confirm>
            )}

            <Modal
              title={action && action[0] === orderStatus.verified.code ? "Баталгаажуулах" : "Цуцлах"}
              visible={!!action}
              onCancel={() => onCancel()}
              destroyOnClose
              footer={false}>
              <ConfirmForm onCancel={onCancel} action={action} onSubmit={onSubmit} />
            </Modal>
          </Col>
        </Row>
      </PageContent>
    </PageContainer>
  );
};
const Checkout = ({ order }) => {
  const getQuantity = () => {
    return order.carts.reduce((accumulator, iterator) => {
      return accumulator + parseInt(iterator.quantity, 10);
    }, 0) + "ш";
  };
  return (
    <StyledCheckout>
      {order.carts.map((cart, index) => (
        <div key={index} className="cart">
          <div className="cart-item">
            <div className="image">
              <img src={cart.image} />
            </div>
            <div className="info">
              <div className="title">{cart.title}</div>
              <div className="body">
                <span className="price">
                  {tugrug(cart.price)} {cart.oldPrice && <span className="sale">{tugrug(cart.oldPrice)}</span>}
                </span>
                <span className="qty">x{cart.quantity}</span>
              </div>
            </div>
          </div>
        </div>
      ))}
      <br />
      <div className="item">
      Тоо хэмжээ <div className="amount">{getQuantity()}</div>
      </div>
      <div className="item">
      Хүргэлт <div className="amount">{tugrug(order.deliveryAmount)}</div>
      </div>
      <div className="item">
      Нийт <div className="amount">{tugrug(order.payAmount)}</div>
      </div>
    </StyledCheckout>
  );
};
const StyledCheckout = styled.div`
  display: flex;
  flex-direction: column;
  .cart {
    .cart-item {
      display: flex;
      flex-direction: row;
      padding: 15px 0;
      border-bottom: 1px solid #ddd;
      .image {
        width: 60px;
        margin-right: 8px;
        img {
          width: 100%;
          border-radius: 2px;
        }
      }
      .info {
        display: flex;
        flex-direction: column;
        .title {
          font-size: 15px;
          font-weight: 500;
          color: #333;
        }
        .body {
          display: flex;
          flex-direction: row;
          align-items: center;
          .price {
            font-size: 18px;
            font-weight: 500;
            margin-right: 5px;
            color: #333;
            .sale {
              color: #6b7478;
              font-size: 13px;
              font-weight: 400;
              text-decoration: line-through;
              padding-left: 10px;
            }
          }
          .qty {
            background: #4a4b57;
            padding: 2px 4px;
            border-radius: 4px;
            font-size: 12px;
            color: #fff;
          }
        }
      }
    }
  }
  .item {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    font-size: 17px;
    color: #333;
    margin-bottom: 5px;
    .amount {
      font-weight: 500;
    }
  }
`;