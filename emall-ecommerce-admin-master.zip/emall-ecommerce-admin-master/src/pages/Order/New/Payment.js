import React from "react";
import styled from "styled-components";
import { Row, Col } from "antd";
import { useSelector, useDispatch } from "react-redux";

const paymentMethods = [{
  title: "ДАНСААР ШИЛЖҮҮЛЭХ",
  value: "bank_account",
}, {
  title: "БЭЛНЭЭР ТӨЛӨХ",
  value: "cash",
}];

export default () => {
  const dispatch = useDispatch();
  const { payment = {} } = useSelector(state => state.checkout);
  const [paymentMethod, setPaymentMethod] = React.useState(payment.method);
  const onPaymentMethod = (value) => {
    setPaymentMethod(value);

    dispatch({
      type   : "payment/update",
      payload: {
        ...payment,
        method: value
      }
    });
  };
  return (
    <Payment>
      <h2>Төлбөрийн нөхцөл</h2>
      <Row>
        {paymentMethods.map((method, i) => (
          <Col span={24} key={i}>
            <PaymentMethod className={paymentMethod === method.value && "active"} onClick={() => onPaymentMethod(method.value)}>
              <div className="content">
                <div className="checkbox">
                  <span className="indicator">
                    <span className="circle"></span>
                  </span>
                </div>
                <div className="text">
                  <h3>{method.title}</h3>
                </div>
              </div>
            </PaymentMethod>
          </Col>
        ))}
      </Row>
    </Payment>
  );
};
const Payment = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  h2 {
    font-size: 17px;
  }
`;
const PaymentMethod = styled.div`
  position: relative;
  margin-bottom: 15px;
  width: 100%;
  height: 46px;
  background-color: white;
  display: flex;
  text-align: left;
  border-width: 2px;
  border-style: solid;
  border-color: rgb(232, 232, 232);
  border-image: initial;
  border-radius: 4px;
  padding: 8px;
  transition: all 200ms ease-in-out 0s;
  flex-direction: column;
  justify-content: space-between;
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  &:hover {
    border: 2px solid #4a4b57;
  }
  &.active {
    border: 2px solid #4a4b57;
    .indicator {
      border-color: #4a4b57;
      .circle {
        transform: scale(1);
      }
    }
  }
  .content {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
  }
  .indicator {
    display: flex;
    width: 24px;
    height: 24px;
    position: absolute;
    left: 20px;
    border-width: 3px;
    border-style: solid;
    border-color: rgb(187, 187, 187);
    border-image: initial;
    border-radius: 50%;
    transition: all 200ms ease-in-out 0s;
    padding: 3px;
    .circle {
      background-color: #2cbf4f;
      width: 12px;
      height: 12px;
      display: inline-block;
      transform: scale(0);
      border-radius: 50%;
      transition: all 200ms ease-in-out 0s;
    }
  }
  .checkbox {
    display: flex;
    flex: 0 0 30px;
    margin-right: 15px;
    img {
      width: 30px;
    }
  }
  .image {
    img {
      width: 80px;
    }
  }
  .text {
    display: flex;
    color: rgb(36, 36, 36);
    flex-direction: column;
    flex: 1;
    text-align: left;
    h3 {
      font-size: 15px;
      margin-bottom: 10px;
    }
    div {
      font-size: 13px;
      color: rgb(102, 102, 102);
    }
  }
`;