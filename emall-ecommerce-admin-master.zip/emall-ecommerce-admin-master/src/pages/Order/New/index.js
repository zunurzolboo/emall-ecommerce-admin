import React from "react";
import { PageContainer, PageContent, PageHeader } from "../../../components/Layout";
import { ProductItem } from "../../../components";
import { Confirm } from "../../../components/Design";
import { Row, Col, Input, Checkbox, Pagination, Cascader, Button, Modal } from "antd";
import { ReloadOutlined } from "@ant-design/icons";
import styled from "styled-components";
import useFetch from "../../../hooks/useFetch";
import { product } from "../../../apis";
import { useDispatch, useSelector } from "react-redux";
import { tugrug } from "../../../utils";
import Cart from "./Cart";
import Checkout from "./Checkout";

const { Search } = Input;

const Filter = (props) => {
  const { categories } = useSelector(state => state.general);
  const [query, setQuery] = React.useState({
    string    : "",
    condition : "",
    categories: undefined
  });

  const onChange = (values) => {
    setQuery(state => ({
      ...state,
      ...values
    }));

    if (props.onChange)
      props.onChange({
        ...query,
        ...values
      });
  };

  return (
    <FilterStyled>
      <div className="row">
        <Search
          size="large"
          placeholder="Эндээс бүхнийг хайж олох..."
          onSearch={value => onChange({ string: value })}
          style={{ width: "100%", height: 44 }}
        />
      </div>
      <div className="row">
        <div className="col">
          <Checkbox checked={query.condition === "new"} onChange={(e) => onChange({ condition: e.target.checked && "new" })}>Шинэ</Checkbox>
        </div>
        <div className="col">
          <Checkbox checked={query.condition === "highlight"} onChange={(e) => onChange({ condition: e.target.checked && "highlight" })}>Онцлох</Checkbox>
        </div>
        <div className="col">
          <Checkbox checked={query.condition === "sale"} onChange={(e) => onChange({ condition: e.target.checked && "sale" })}>Хямдралтай</Checkbox>
        </div>
        <div className="col" style={{ marginLeft: 20 }}>
          <Cascader placeholder="Бүх ангилал" fieldNames={{ label: "name", value: "_id" }} options={categories} name="categories" onChange={value => onChange({ categories: value })} />
        </div>
        <div className="col">
          <Button onClick={() => onChange({
            string    : "",
            condition : "",
            categories: undefined
          })}><ReloadOutlined /></Button>
        </div>
      </div>
    </FilterStyled>
  );
};

export default () => {
  const dispatch = useDispatch();
  const [visible, setVisible] = React.useState(false);
  const [query, setQuery] = React.useState({ page: 1 });
  const [{ rows, count }] = useFetch(product.search, query)({ rows: [], count: 0 });
  const { carts } = useSelector(state => state.checkout);
  const onFilter = (filter) => {
    setQuery(state => ({
      ...state,
      ...filter
    }));
  };
  const onAddCart = (item) => {
    dispatch({
      type   : "cart/add",
      payload: {
        ...item,
        product: item._id,
        qty    : 1
      }
    });
  };
  const onChagnePagination = (page) => {
    setQuery(state => ({
      ...state,
      page
    }));
  };
  const getTotalAmount = () => {
    return tugrug(carts.reduce((accumulator, iterator) => {
      return accumulator + (iterator.qty * iterator.price);
    }, 0));
  };
  const onCancel = () => {
    setVisible(false);
  };
  const onConfirm = () => {
    if (carts.length > 0)
      setVisible(true);
  };

  return (
    <PageContainer>
      <PageHeader>
        <h2>Захиалга</h2>
      </PageHeader>
      <PageContent>
        <Row gutter={20}>
          <Col span={16}>
            <Filter onChange={onFilter} />
            <div className="product-grid">
              {rows.map((item, index) => <ProductItem key={index} className="product-item" item={item} onAddCart={onAddCart} />)}
            </div>
            {count > 0 && <Pagination style={{ marginTop: 20 }} current={query.page} total={count} onChange={onChagnePagination} />}
          </Col>
          <Col span={8}>
            <div className="emall-card">
              <Cart />
              <Confirm className="primary" style={{ padding: 5 }}>
                <Button size="large" type="primary" onClick={() => onConfirm()} block>
                  <div className="name">
                    Үргэлжлүүлэх
                    <div>Баталгаажуулах</div>
                  </div>
                  <div className="amount">{getTotalAmount()}</div>
                </Button>
              </Confirm>
            </div>
          </Col>
        </Row>
      </PageContent>
      <Modal
        className="emall-product-modal"
        footer={null}
        onCancel={() => setVisible(false)}
        visible={visible}>
        <Checkout onCancel={onCancel}/>
      </Modal>
    </PageContainer>
  );
};
const FilterStyled = styled.div`
  .row {
    display: flex;
    flex-direction: row;
    align-items: center;
    margin-bottom: 15px;
    .col {
      display: flex;
      flex-direction: column;
      margin-right: 5px;
    }
  }
`;