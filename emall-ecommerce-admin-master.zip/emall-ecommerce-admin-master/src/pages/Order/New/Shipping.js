import React from "react";
import styled from "styled-components";
import { Form, FormItem, Input, Select } from "formik-antd";
import { InfoCircleOutlined, UserOutlined, BankOutlined } from "@ant-design/icons";
import { Row, Col } from "antd";
import { Formik, useFormikContext } from "formik";
import * as Yup from "yup";
import { useSelector, useDispatch } from "react-redux";

const { TextArea } = Input;

const FormSchema = Yup.object().shape({
  ownerType: Yup.string().required(),
  firstName: Yup.string().when("ownerType", {
    is  : "citizen",
    then: Yup.string().required("Заавал бөглөнө!").max(100)
  }),
  lastName: Yup.string().when("ownerType", {
    is  : "citizen",
    then: Yup.string().required("Заавал бөглөнө!").max(100)
  }),
  companyName: Yup.string().when("ownerType", {
    is  : "organization",
    then: Yup.string().required("Заавал бөглөнө!").max(100)
  }),
  companyRegister: Yup.string().when("ownerType", {
    is  : "organization",
    then: Yup.string().required("Заавал бөглөнө!").max(100)
  }),
  phone   : Yup.number().required("Заавал бөглөнө!").min(10000000).max(99999999),
  tel     : Yup.number().optional().min(10000000).max(99999999),
  email   : Yup.string().required("Заавал бөглөнө!").max(100),
  province: Yup.string().required("Заавал бөглөнө!"),
  district: Yup.string().required("Заавал бөглөнө!"),
  quarter : Yup.string().when("province", {
    is  : 1,
    then: Yup.string().required("Заавал бөглөнө!")
  }),
  place: Yup.string().when("province", {
    is  : 1,
    then: Yup.string().required("Заавал бөглөнө!")
  }),
  placeCode: Yup.string().when("province", {
    is  : 1,
    then: Yup.string().required("Заавал бөглөнө!")
  }),
  address: Yup.string().required("Заавал бөглөнө!").max(500)
});

const SubmitForm = React.forwardRef((props, ref) => {
  const { validateForm, submitForm } = useFormikContext();

  React.useImperativeHandle(ref, () => ({
    async submitForm() {
      await submitForm();

      let errors = await validateForm();

      if (Object.keys(errors).length > 0)
        return false;

      return true;
    }
  }));

  return null;
});

const initialValues = {
  ownerType      : "citizen",
  firstName      : undefined,
  lastName       : undefined,
  companyName    : undefined,
  companyRegister: undefined,
  phone          : undefined,
  tel            : undefined,
  email          : undefined,
  province       : undefined,
  district       : undefined,
  quarter        : undefined,
  place          : undefined,
  placeCode      : undefined,
  address        : undefined
};

export default React.forwardRef((props, ref) => {
  const { user } = useSelector(state => state.auth);
  const { cities, districts, quarters, isMobile } = useSelector(state => state.general);
  const { shipping } = useSelector(state => state.checkout);
  const dispatch = useDispatch();
  const [data, setFormData] = React.useState({ ...initialValues, ...shipping, ...user });
  const submitRef = React.useRef();
  const onSubmit = async (data) => {
    dispatch({
      type   : "shipping/update",
      payload: data
    });
  };
  const onOwnerType = (type) => {
    setFormData(state => ({
      ...state,
      ownerType: type
    }));
  };
  const onProvince = (value) => {
    setFormData(state => ({
      ...state,
      province: value
    }));
  };
  const onDistrict = (value) => {
    setFormData(state => ({
      ...state,
      district: value
    }));
  };

  React.useImperativeHandle(ref, () => ({
    async validate() {
      let isValid = await submitRef.current.submitForm();
      return isValid;
    }
  }));

  return (
    <Shipping className="emall-card">
      <div className="header">
        <h2>Хүргэлтийн мэдээлэл</h2>
      </div>
      <div className="body">
        <Formik
          enableReinitialize
          initialValues={{ ...initialValues, ...shipping, ...user }}
          validationSchema={FormSchema}
          onSubmit={onSubmit}>
          {() => (
            <Form layout="vertical">
              <Row gutter={15} className="radio-owner-type">
                <Col span={12}>
                  <a className={`btn btn-block citizen ${data.ownerType === "citizen" && "active"}`} onClick={() => onOwnerType("citizen")} href="#">
                    <UserOutlined /> Иргэн
                  </a>
                </Col>
                <Col span={12}>
                  <a className={`btn btn-block organization ${data.ownerType === "organization" && "active"}`} onClick={() => onOwnerType("organization")} href="#">
                    <BankOutlined /> Байгууллага
                  </a>
                </Col>
              </Row>
              {data.ownerType === "citizen" ? (
                <Row gutter={15}>
                  <Col span={12}>
                    <FormItem label="Овог" name="lastName" required>
                      <Input size="large" name="lastName" placeholder="Овог" />
                    </FormItem>
                  </Col>
                  <Col span={12}>
                    <FormItem label="Нэр" name="firstName" required>
                      <Input size="large" name="firstName" placeholder="Нэр" />
                    </FormItem>
                  </Col>
                </Row>
              ) : (
                <Row gutter={15}>
                  <Col span={12}>
                    <FormItem label="Байгууллагын нэр" name="companyName" required>
                      <Input size="large" name="companyName" placeholder="Байгууллагын нэр" />
                    </FormItem>
                  </Col>
                  <Col span={12}>
                    <FormItem label="Байгууллагын регистер" name="companyRegister" required>
                      <Input size="large" name="companyRegister" placeholder="Байгууллагын регистер" />
                    </FormItem>
                  </Col>
                </Row>
              )}
              <hr />
              <Row gutter={15}style={{ marginBottom: 40 }}>
                <Col span={12}>
                  <FormItem label="Утасны дугаар" name="phone" required help={
                    <div className="explain">
                      <InfoCircleOutlined /> Манай ажилтан утсаар холбогдох тул дугаараа үнэн зөв оруулна уу.
                    </div>
                  }>
                    <Input size="large" name="phone" placeholder="Утасны дугаар" />
                  </FormItem>
                </Col>
                <Col span={12}>
                  <FormItem label="Имэйл" name="email" required help={
                    <div className="explain">
                      <InfoCircleOutlined /> Таны имэйл хаягаар төлбөрийн баримт очих тул үнэн зөв бөглөнө үү.
                    </div>
                  }>
                    <Input size="large" name="email" required placeholder="Имэйл" />
                  </FormItem>
                </Col>
              </Row>
              <Row gutter={15}>
                <Col span={12}>
                  <FormItem label="Утасны дугаар #2" name="tel">
                    <Input size="large" name="tel" placeholder="Утасны дугаар" />
                  </FormItem>
                </Col>
              </Row>
              <hr />
              <Row gutter={15}>
                <Col span={12}>
                  <FormItem label="Хот/Аймаг" name="province" required>
                    <Select size="large" name="province" onChange={onProvince} placeholder="Сонгох">
                      {cities.map((city, i) => (
                        <Select.Option key={i} value={city.id}>
                          {city.name}
                        </Select.Option>
                      ))}
                    </Select>
                  </FormItem>
                </Col>
                <Col span={12}>
                  <FormItem label="Дүүрэг/Сум" name="district" required>
                    <Select size="large" name="district" onChange={onDistrict} placeholder="Сонгох">
                      {districts.filter(district => district.city === data.province).map((city, i) => (
                        <Select.Option key={i} value={city.id}>
                          {city.name}
                        </Select.Option>
                      ))}
                    </Select>
                  </FormItem>
                </Col>
              </Row>
              {data.province === 1 && (
                <Row gutter={15}>
                  <Col span={12}>
                    <FormItem label="Баг/Хороо" name="quarter" required>
                      <Select size="large" name="quarter" placeholder="Сонгох">
                        {quarters.filter(quarter => quarter.district === data.district).map((city, i) => (
                          <Select.Option key={i} value={city.id}>
                            {city.name}
                          </Select.Option>
                        ))}
                      </Select>
                    </FormItem>
                  </Col>
                </Row>
              )}
              {data.province === 1 && (
                <Row gutter={15}>
                  <Col span={12}>
                    <FormItem label="Байр" name="place" required>
                      <Input size="large" name="place" placeholder="Байр" />
                    </FormItem>
                  </Col>
                  <Col span={12}>
                    <FormItem label="Орцны код" name="placeCode" required>
                      <Input size="large" name="placeCode" placeholder="Орцны код" />
                    </FormItem>
                  </Col>
                </Row>
              )}
              <Row gutter={15}>
                <Col className="col-12">
                  <FormItem label="Дэлгэрэнгүй хаяг" name="address" required help={
                    <div className="explain">
                      <InfoCircleOutlined /> Та хаягаа зөв дэлгэрэнгүй, тодорхой оруулаагүйгээс үүдэн хүргэлт удаашрах, эсвэл хүргэгдэхгүй байж болзошгүйг анхаарна уу.
                    </div>
                  }>
                    <TextArea size="large" name="address" placeholder="Дэлгэрэнгүй хаяг" />
                  </FormItem>
                </Col>
              </Row>

              <SubmitForm ref={submitRef} />
            </Form>
          )}
        </Formik>
      </div>
    </Shipping>
  );
});
const Shipping = styled.div`
  hr {
    margin-top: 1rem;
    margin-bottom: 1rem;
    border: 0;
    border-top: 1px solid rgba(0, 0, 0, 0.1);
  }
  .radio-owner-type {
    display: flex;
    flex-direction: row;
    margin-bottom: 20px;
    .btn {
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: center;
      border-radius: 4px;
      font-weight: 600;
      height: 44px;
      font-size: 15px;
      color: rgb(36, 36, 36);
      border: 2px solid #494b57;
      &:hover {
        color: #4b5156;
        border-color: #4b5156;
      }
      &.active {
        background: #4a4b57;
        border-color: #333;
        color: #fff;
        &:hover {
          background: #585f65;
        }
      }
      .anticon {
        display: inline-flex;
        margin-right: 10px;
      } 
    }
  }
  .explain {
    line-height: 18px;
    margin-top: 5px;
    padding: 4px;
    color: #555;
    display: flex;
    font-size: 14px;

    .anticon {
      display: inline-flex;
      margin-right: 5px;
      color: #faad14;
      margin-top: 2px;
    }
  }
`;