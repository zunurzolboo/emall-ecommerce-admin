import React from "react";
import { PageContainer, PageContent, PageHeader } from "../../../components/Layout";
import { Row, Col, Button, Input } from "antd";
import styled from "styled-components";
import { Confirm } from "../../../components/Design";
import { useSelector, useDispatch } from "react-redux";
import Shipping from "./Shipping";
import { tugrug } from "../../../utils";
import Cart from "./Cart";
import Payment from "./Payment";
import { order } from "../../../apis";

export default (props) => {
  const dispatch = useDispatch();
  const [loading, setLoading] = React.useState(false);
  const { shipping, payment, carts, additional } = useSelector(state => state.checkout);
  const shippingRef = React.useRef();
  const getDeliveryAmount = () => {
    return tugrug(3000);
  };
  const getTotalAmount = () => {
    return tugrug(carts.reduce((accumulator, iterator) => {
      return accumulator + (iterator.qty * iterator.price);
    }, 3000));
  };
  const onAdditional = (value) => {
    dispatch({
      type   : "shipping/additional",
      payload: value
    });
  };
  const onConfirm = async () => {
    let isValid = await shippingRef.current.validate();

    if (isValid === true) {
      setLoading(true);
      await order.create({
        shipping,
        payment,
        carts: carts.map(cart => ({
          product : cart.product,
          quantity: cart.qty
        })),
        additional
      });

      dispatch({
        type: "cart/clear"
      });

      setLoading(false);

      if (props.onCancel)
        props.onCancel();
    }
  };

  return (
    <PageContainer style={{ padding: "0 15px" }}>
      <PageHeader>
        <h2>Баталгаажуулах</h2>
      </PageHeader>
      <PageContent>
        <Row gutter={20}>
          <Col span={16}>
            <Shipping ref={shippingRef} />
          </Col>
          <Col span={8}>
            <div className="emall-card">
              <Cart />
            </div>
            <Checkout className="emall-card">
              <div className="header">
                <h2>Төлбөр</h2>
              </div>
              <div className="body">
                <div className="item">
                  <Payment />
                </div>
                <hr />
                <div className="item">
                  Хүргэлт <div className="amount">{getDeliveryAmount()}</div>
                </div>
                <div className="item">
                  Нийт <div className="amount">{getTotalAmount()}</div>
                </div>
              </div>
            </Checkout>

            <Additional className="emall-card">
              <div className="header">
                <h2>Нэмэлт тайлбар</h2>
              </div>
              <Input.TextArea size="large" onChange={e => onAdditional(e.target.value)} />
            </Additional>

            <Confirm className="success">
              <Button loading={loading} size="large" type="primary" onClick={() => onConfirm()} block>
                <div className="name">
                  Баталгаажуулах
                  <div>Хүргэлтэд</div>
                </div>
                <div className="amount">{getTotalAmount()}</div>
              </Button>
            </Confirm>
          </Col>
        </Row>
      </PageContent>
    </PageContainer>
  );
};
const Additional = styled.div`
  margin-bottom: 20px;
  textarea {
    border: none;
  }
`;
const Checkout = styled.div`
  margin: 20px 0;
  .item {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    font-size: 16px;
    color: #333;
    margin-bottom: 10px;
    .amount {
      font-weight: 500;
    }
  }
`;