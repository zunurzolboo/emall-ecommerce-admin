import React from "react";
import { Form, FormItem, Input } from "formik-antd";
import { Button, Form as AntForm, Result } from "antd";
import { Formik } from "formik";
import * as Yup from "yup";
import { useSelector } from "react-redux";

const FormSchema = Yup.object().shape({
  additional: Yup.string().required("Заавал бөглөнө!").min(2, "2-ooс дээш урттай байна!").max(500, "500-аас доош тэмдэгт оруулна уу!")
});

export default ({ action, onSubmit }) => {
  const { orderStatus } = useSelector(state => state.general);
  const [data] = React.useState({
    additional: ""
  });

  return (
    <div>
      <Formik
        enableReinitialize
        initialValues={data}
        validationSchema={FormSchema}
        onSubmit={onSubmit}>
        {({ isSubmitting }) => (
          <Form layout="vertical">
            <Result
              style={{ padding: 0 }}
              status={action[0] === orderStatus.verified.code ? "success" : "error"}
              title={action[0] === orderStatus.verified.code ? "Баталгаажуулах" : "Цуцлах"}
              subTitle="Та нэмэлт тайлбар оруулна уу!"
            />
            <FormItem name="additional" label="Нэмэлт тайлбар" required>
              <Input.TextArea size="large" name="additional" />
            </FormItem>
            <AntForm.Item>
              <Button htmlType="submit" size="large" type="primary" loading={isSubmitting} block>Илгээх</Button>
            </AntForm.Item>
          </Form>
        )}
      </Formik>
    </div>
  );
};
