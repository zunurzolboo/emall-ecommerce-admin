import React from "react";
import { Tag, Button } from "antd";
import { MyTable } from "../../components";
import { order } from "../../apis";
import { PageContainer, PageHeader, PageContent } from "../../components/Layout";
import { useSelector } from "react-redux";
import { tugrug } from "../../utils";
import { Link, useHistory } from "react-router-dom";
import moment from "moment";
import { RowAction } from "../../components";

export default () => {
  const { orderStatus } = useSelector(state => state.general);
  const history = useHistory();
  const myTableRef = React.useRef(null);
  const columns = useHeader({
    orderStatus,
    onClick: (key, order) => {
      switch (key) {
        case "detail": {
          history.push(`/order/detail/${order._id}`);
          break;
        }
        default:
      }
    }
  });

  return (
    <PageContainer>
      <PageHeader>
        <h2>Захиалга</h2>
        <div>
          <Link to="/order/new">
            <Button>Шинэ захиалга</Button>
          </Link>
        </div>
      </PageHeader>

      <PageContent>
        <MyTable
          ref={myTableRef}
          rowKey={record => record.id}
          columns={columns}
          loadData={order.list}
        />
      </PageContent>
    </PageContainer>
  );
};

const useHeader = ({ orderStatus, onClick }) => {
  return [{
    title : "#",
    key   : "orderEm",
    render: (order) => {
      return <Link to={`/order/detail/${order._id}`}>{order.orderEm}</Link>;
    }
  }, {
    title    : "Нэр",
    key      : "name",
    dataIndex: "shipping",
    render   : (shipping) => {
      return `${shipping.lastName || ""} ${shipping.firstName || ""}`;
    },
  }, {
    title    : "Утас",
    key      : "phone",
    dataIndex: "shipping",
    render   : (shipping) => {
      return `${shipping.phone} ${shipping.tel || ""}`;
    }
  }, {
    title    : "Хаяг",
    key      : "address",
    dataIndex: "shipping",
    render   : (shipping) => {
      return shipping.address;
    }
  }, {
    title    : "Төлбөрийн нөхцөл",
    key      : "payment",
    dataIndex: "payment",
    render   : (payment) => {
      return <Tag>{payment.methodName}</Tag>;
    }
  }, {
    title : "Төлөв",
    key   : "status",
    render: (order) => {
      const status = orderStatus[order.orderStatus];

      if (!status) return;

      return (
        <>
          <Tag color={status.color} style={{ display: "block" }}>{order.orderStatusName}</Tag>
          {order.erpOrderId && <Tag color={order.orderStatus === "verified" ? "blue" : "red" } style={{ display: "block", marginTop: 5, textAlign: "center" }}>{order.erpOrderId}</Tag>}
        </>
      );
    }
  }, {
    title : "Төлөх дүн",
    key   : "payAmount",
    render: (order) => {
      return tugrug(order.payAmount);
    }
  }, {
    title : "Огноо",
    key   : "date",
    render: (order) => {
      return <span>{moment(order.createdAt).format("YYYY-MM-DD HH:mm:ss")}</span>;
    }
  }, {
    title : "Үйлдэл",
    key   : "action",
    render: (order) => {
      return <RowAction actions={{
        detail: "Дэлгэрэнгүй",
      }} onClick={(key) => onClick(key, order)} />;
    }
  }];
};