import Dashboard from "./Dashboard";
import Login from "./Login";
import Me from "./Me";
import ChangePassword from "./ChangePassword";
import Product from "./Product";
import ProductNew from "./Product/New";
import ProductEdit from "./Product/Edit";
import Brand from "./Brand";
import Tag from "./Tag";
import Sale from "./Sale";
import Category from "./Category";
import Home from "./Home";
import Option from "./Option";
import Attribute from "./Attribute";
import Color from "./Color";
import Banner from "./Banner";
import Order from "./Order";
import OrderDetail from "./Order/Detail";
import Notfound from "./404";
import Highlight from "./Highlight";
import NewOrder from "./Order/New";
import Delivery from "./Delivery";
import Staff from "./Staff";

export {
  Me,
  ChangePassword,
  Login,
  Product,
  ProductNew,
  ProductEdit,
  Tag,
  Brand,
  Dashboard,
  Sale,
  Home,
  Category,
  Option,
  Attribute,
  Color,
  Order,
  OrderDetail,
  Banner,
  Notfound,
  Highlight,
  NewOrder,
  Delivery,
  Staff
};
