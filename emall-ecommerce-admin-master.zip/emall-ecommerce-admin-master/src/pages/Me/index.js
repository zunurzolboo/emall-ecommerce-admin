import React from "react";
import ChangePassword from "../ChangePassword";

const Me = () => {
  return (
    <div className="qp-box">
      <ChangePassword />
    </div>
  );
};
export default Me;
